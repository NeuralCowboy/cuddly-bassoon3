import {useEffect, useState} from 'react';
import {request} from './bridge';

export function Settings({run, busy, onSave}) {
  const [values, setValues] = useState(null);
  const [status, setStatus] = useState('');
  const [edited, setEdited] = useState(false);
  useEffect(() => {
    request('settings').then(setValues).catch(error => setStatus(error.message));
  }, []);
  if (!values) return <section className="panel settings">{status || '读取中…'}</section>;

  function change(key, value) {
    setValues(current => ({...current, [key]: value}));
    setEdited(true);
    setStatus('');
  }

  const field = (key, label, placeholder, type = 'text') => <label>
    {label}
    <input type={type} placeholder={placeholder} value={values[key] ?? ''} disabled={busy}
      onChange={event => change(key, event.target.value)} />
  </label>;
  const toggle = (key, label) => <label className="check">
    <input type="checkbox" checked={!!values[key]} disabled={busy} onChange={event => change(key, event.target.checked)} />
    {label}
  </label>;

  function useDeepSeek() {
    setValues(current => ({
      ...current,
      base_url: 'https://api.deepseek.com',
      chat_model: 'deepseek-flash',
    }));
    setEdited(true);
    setStatus('');
  }

  function save(event) {
    event.preventDefault();
    setStatus('');
    run(async () => {
      const saved = await request('save', values);
      setValues(saved);
      setEdited(false);
      onSave(saved);
      setStatus('已保存');
    });
  }

  return <section className="panel settings">
    <div className="settings-heading">
      <h1>模型设置</h1>
      <button type="button" disabled={busy} onClick={useDeepSeek}>DeepSeek</button>
    </div>
    <form onSubmit={save}>
      {field('base_url', '接口地址', '输入接口地址')}
      {field('chat_model', '读图模型', '输入模型名称')}
      {field('key', 'API Key', values.hasKey ? '已设置，留空沿用' : '输入密钥', 'password')}
      <div className="settings-actions">
        <button className="primary" type="submit" disabled={busy}>保存</button>
        <button type="button" disabled={busy || edited || !values.base_url || !values.chat_model} onClick={() => {
          setStatus('');
          run(async report => {
            report('正在测试读图…');
            await request('testModel');
            setStatus('读图连接正常');
          });
        }}>测试连接</button>
        <small role="status">{status}</small>
      </div>
      <details className="settings-extra">
        <summary>更多选项</summary>
        {toggle('remember', '记住密钥')}
        {values.hasKey && toggle('clearKey', '清除密钥')}
        {toggle('confirmCloudExtraction', '提取前确认')}
        {field('embedding_model', 'Embedding 模型')}
        {field('rerank_model', '重排模型')}
        {toggle('hybrid', '混合检索')}
        {toggle('rerank', '重排序')}
        <button type="button" disabled={busy} onClick={() => run(() => request('export'))}>导出最近回答</button>
        <small className="settings-note">模型任务会把相关图文发送到配置的接口。</small>
      </details>
    </form>
  </section>;
}
