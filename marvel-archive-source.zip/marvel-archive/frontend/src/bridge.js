let connection;
let sequence = 0;
function connect() {
  connection ??= new Promise((resolve, reject) => {
    if (!window.qt || !window.QWebChannel) {
      reject(new Error('请通过桌面启动器打开知识库'));
      return;
    }
    new window.QWebChannel(window.qt.webChannelTransport, ({objects}) => resolve(objects.archive));
  });
  return connection;
}

let queue = Promise.resolve();
export function request(action, data = {}, onProgress) {
  const result = queue.then(() => dispatch(action, data, onProgress));
  queue = result.catch(() => {});
  return result;
}

async function dispatch(action, data, onProgress) {
  const bridge = await connect();
  const id = String(++sequence);
  return new Promise((resolve, reject) => {
    function complete(responseId, value, error) {
      if (id !== responseId) return;
      bridge.completed.disconnect(complete);
      if (onProgress) bridge.progress.disconnect(onProgress);
      if (error) reject(new Error(error));
      else {
        try { resolve(JSON.parse(value)); } catch (error) { reject(error); }
      }
    }
    bridge.completed.connect(complete);
    if (onProgress) bridge.progress.connect(onProgress);
    bridge.request(id, action, JSON.stringify(data));
  });
}

export async function chooseFiles() {
  const bridge = await connect();
  return JSON.parse(await new Promise(resolve => bridge.choose(resolve)));
}
