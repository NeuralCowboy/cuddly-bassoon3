import {useEffect, useState} from 'react';
const slides = [
  ['蜘蛛侠', 'marvel.jpg'], ['黑豹', 'banners/black-panther.jpg'],
  ['美国队长', 'banners/captain-america.png'], ['死侍', 'banners/deadpool.jpg'],
  ['奇异博士', 'banners/doctor-strange.jpg'], ['钢铁侠', 'banners/iron-man.jpg'],
  ['雷神', 'banners/thor.jpg'],
];
export function Carousel() {
  const [index, select] = useState(0);
  const [paused, pause] = useState(false);
  useEffect(() => {
    if (paused) return;
    const timer = setTimeout(() => select((index + 1) % slides.length), 4500);
    return () => clearTimeout(timer);
  }, [index, paused]);
  return <div className="carousel" onMouseEnter={() => pause(true)} onMouseLeave={() => pause(false)}>
    <img key={index} src={slides[index][1]} alt={slides[index][0]} />
    <div className="dots">{slides.map(([name], i) => <button key={name} aria-label={name}
      aria-pressed={i === index} onClick={() => select(i)} />)}</div>
  </div>;
}
