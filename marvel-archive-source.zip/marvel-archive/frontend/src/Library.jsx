import {useEffect, useState} from 'react';
import {chooseFiles, request} from './bridge';

export function Library({run, busy, selected, select}) {
  const [pages, setPages] = useState([]);
  const [preview, setPreview] = useState(null);
  const [series, setSeries] = useState('');
  const [issue, setIssue] = useState('');
  const [error, setError] = useState('');
  const [status, setStatus] = useState('');
  async function refresh() { setPages(await request('pages')); }
  function extractLocal(pageId) {
    run(async progress => {
      setStatus(await request('extractLocal', {page_id: pageId}, progress));
      await refresh();
      if (pageId && pageId === selected) setPreview(await request('preview', {page_id: pageId}));
    });
  }
  useEffect(() => { refresh().catch(error => setError(error.message)); }, []);
  useEffect(() => {
    let active = true;
    setPreview(null);
    if (selected) request('preview', {page_id: selected}).then(data => {
      if (active) setPreview(data);
    }).catch(error => { if (active) setError(error.message); });
    return () => { active = false; };
  }, [selected]);
  return <section className="panel">
    <h1>漫画书架</h1>
    {error && <p role="alert">{error}</p>}
    <div className="actions">
      <input placeholder="系列名（建议含年份）" value={series} onChange={e => setSeries(e.target.value)} />
      <input placeholder="期号" value={issue} onChange={e => setIssue(e.target.value)} />
      <button disabled={busy || !series.trim() || !issue.trim()} onClick={async () => {
        const files = await chooseFiles();
        if (files.length) await run(async () => setPages(await request('import', {series, issue, files: files.map(f => f.id)})));
      }}>导入漫画</button>
      <button disabled={busy || !selected} onClick={() => extractLocal(selected)}>本地 OCR 当前页</button>
      <button disabled={busy} onClick={() => extractLocal(null)}>批量本地 OCR</button>
      <button disabled={busy} onClick={() => run(async progress => {
        const settings = await request('settings');
        if (settings.confirmCloudExtraction &&
            !window.confirm('将待提取页面发送到所配置的模型接口，是否继续？')) return;
        setStatus('正在使用所配置的模型接口提取待处理页面…');
        await request('extract', {}, progress);
        await refresh();
        setStatus('云端视觉提取完成');
      })}>云端视觉提取</button>
      <button disabled={busy} onClick={() => run(async progress => {
        const message = await request('index', {}, progress); setStatus(message);
      })}>建立向量索引</button>
    </div>
    {status && <p role="status">{status}</p>}
    <div className="shelf">
      <aside>{pages.map(p => <button disabled={busy} key={p.page_id} aria-pressed={selected === p.page_id}
        onClick={() => select(p.page_id)}>{p.series_title} #{p.issue_number} · 第 {p.file_page_index} 页
        <small>{p.extracted ? '已提取' : '待提取'}</small></button>)}</aside>
      <div>{preview ? <>
        <img className="preview" src={preview.image} alt="漫画原页" />
        <label>对白原文<textarea value={preview.ocr} onChange={e => setPreview({...preview, ocr: e.target.value})} /></label>
        <label>画面描述<textarea value={preview.description} onChange={e => setPreview({...preview, description: e.target.value})} /></label>
        <button disabled={busy} onClick={() => run(async () => {
          await request('correct', {page_id: selected, ocr: preview.ocr, description: preview.description});
          await refresh();
        })}>保存校对</button>
      </> : <p>选择页面查看原图。导入后可手动校对或使用模型提取。</p>}</div>
    </div>
  </section>;
}
