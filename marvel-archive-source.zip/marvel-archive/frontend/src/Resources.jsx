import {useEffect, useState} from 'react';
import {request} from './bridge';
export function Resources({run}) {
  const [term, setTerm] = useState('');
  const [rows, setRows] = useState([]);
  useEffect(() => { request('resources').then(setRows).catch(() => {}); }, []);
  function search(event) {
    event.preventDefault();
    run(async () => setRows(await request('resources', {term})));
  }
  return <section className="panel"><h1>在线资料</h1><p>来源目录与阅读入口。故事问答使用书架中的正文证据。</p>
    <form className="actions" onSubmit={search}><input value={term} onChange={e => setTerm(e.target.value)} placeholder="搜索英文系列名…" /><button>搜索</button></form>
    <p>显示 {rows.length} 条 · 每次最多 500 条</p>
    <ul className="resources">{rows.map(row => <li key={row.url}><button onClick={() => run(() => request('open', {url: row.url}))}>{row.title} ↗</button><small>{row.access}</small></li>)}</ul>
  </section>;
}
