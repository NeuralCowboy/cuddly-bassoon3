import {useEffect, useRef} from 'react';
import {Carousel} from './Carousel';
import {chooseFiles} from './bridge';

function Reply({result, openSettings}) {
  if (result.message) return <p>{result.message}</p>;
  if (result.answer?.insufficient_evidence) {
    return <p>当前漫画里的剧情信息不足。可以补充相关漫画，或问一个更具体的片段。</p>;
  }
  if (result.answer) {
    return result.answer.claims.map((paragraph, i) => <p key={i}>{paragraph.text}</p>);
  }
  return result.evidence?.length ? <>
    <p>已找到相关漫画内容。请配置主模型来阅读画格和对白，生成故事讲述。</p>
    <button onClick={openSettings}>打开模型设置</button>
  </> : <p>未找到相关漫画内容。</p>;
}

export function Chat({turns, draft, setDraft, send, openSettings, modelConfigured, busy, progress, error}) {
  const {text, files} = draft;
  const end = useRef(null);
  const home = turns.length === 0;
  useEffect(() => { end.current?.scrollIntoView({behavior: 'smooth'}); }, [turns, progress]);
  function submit() {
    if (busy || (!text.trim() && !files.length)) return;
    send(text.trim() || '请读懂所附漫画的画格和对白，按情节讲述这个故事。', files);
  }
  return <section className={'chat ' + (home ? 'home' : '')}>
    {home ? <Carousel /> : <div className="transcript" aria-live="polite">{turns.map((turn, i) =>
      <article className={turn.role} key={i}><small>{turn.role === 'user' ? '你' : turn.result?.answer ? '故事研究员' : '资料检索'}</small>
        {turn.result ? <Reply result={turn.result} openSettings={openSettings} /> : <p>{turn.text}</p>}
      </article>)}<div ref={end} /></div>}
    <div className="composer">
      {error && <p className="chat-error" role="alert">{error}</p>}
      {modelConfigured === false && <button className="setup-model" disabled={busy} onClick={openSettings}>配置模型以生成故事 →</button>}
      {files.length > 0 && <p>{files.map(file => file.name).join(' · ')} <button disabled={busy} onClick={() => setDraft({...draft, files: []})}>移除附件</button></p>}
      <textarea aria-label="故事问题" placeholder="想找哪个故事？也可以附上漫画文件…" value={text}
        readOnly={busy} onChange={event => setDraft({...draft, text: event.target.value})} onKeyDown={event => {
          if (event.key === 'Enter' && !event.shiftKey && !event.nativeEvent.isComposing && event.keyCode !== 229) {
            event.preventDefault(); submit();
          }
        }} />
      <div className="actions"><button disabled={busy} onClick={async () => {
        const picked = await chooseFiles();
        if (picked.length) setDraft(current => ({...current, files: picked}));
      }}>＋ 附加漫画</button><span role="status">{progress}</span><button className="primary" disabled={busy || (!text.trim() && !files.length)} onClick={submit}>发送 ↑</button></div>
    </div>
  </section>;
}
