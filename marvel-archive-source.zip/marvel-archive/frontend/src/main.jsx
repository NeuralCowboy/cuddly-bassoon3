import {useEffect, useRef, useState} from 'react';
import {createRoot} from 'react-dom/client';
import {request} from './bridge';
import {Chat} from './Chat';
import {Library} from './Library';
import {Settings} from './Settings';
import {Resources} from './Resources';
import './style.css';

function App() {
  const [tab, setTab] = useState('故事对话');
  const [turns, setTurns] = useState([]);
  const [selected, select] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [progress, setProgress] = useState('');
  const [modelConfigured, setModelConfigured] = useState(null);
  const [draft, setDraft] = useState({text: '', files: []});
  const locked = useRef(false);
  function updateModel(settings) {
    setModelConfigured(Boolean(settings.base_url && settings.chat_model));
  }
  useEffect(() => {
    request('settings').then(updateModel).catch(error => setError(error.message));
  }, []);
  async function run(action) {
    if (locked.current) return;
    locked.current = true;
    setBusy(true);
    setError('');
    setProgress('处理中…');
    try { await action(setProgress); }
    catch (error) { setError(error.message); }
    finally { locked.current = false; setBusy(false); setProgress(''); }
  }
  function send(question, files) {
    run(async report => {
      const history = turns.slice(-6).map(turn => ({role: turn.role, content: turn.text ?? turn.result?.answer?.claims?.map(c => c.text).join('\n') ?? ''}));
      const user = {role: 'user', text: [question, ...files.map(file => file.name)].join('\n')};
      setTurns(previous => [...previous, user]);
      try {
        const result = await request('ask', {question, history, files: files.map(file => file.id)}, report);
        setTurns(previous => [...previous, {role: 'assistant', result}]);
        setDraft({text: '', files: []});
      } catch (error) {
        setTurns(previous => previous.filter(turn => turn !== user));
        throw error;
      }
    });
  }
  return <><header><strong>MARVEL <span>ARCHIVE</span></strong><nav>
    {['故事对话', '漫画书架', '在线资料', '模型设置'].map(name => <button key={name}
      disabled={busy} aria-current={tab === name ? 'page' : undefined} onClick={() => {setTab(name); setError('');}}>{name}</button>)}</nav>
    <button disabled={busy} onClick={() => {setTurns([]); setDraft({text: '', files: []}); setError(''); setTab('故事对话');}}>新对话</button></header>
    {tab !== '故事对话' && error && <div className="error" role="alert">{error}<button onClick={() => setError('')}>关闭</button></div>}
    {tab !== '故事对话' && progress && <p className="progress" role="status">{progress}</p>}
    {tab === '故事对话' && <Chat turns={turns} draft={draft} setDraft={setDraft} send={send}
      openSettings={() => {setError(''); setTab('模型设置');}} modelConfigured={modelConfigured}
      busy={busy} progress={progress} error={error} />}
    {tab === '漫画书架' && <Library run={run} busy={busy} selected={selected} select={select} />}
    {tab === '模型设置' && <Settings run={run} busy={busy} onSave={updateModel} />}
    {tab === '在线资料' && <Resources run={run} />}
  </>;
}
createRoot(document.getElementById('root')).render(<App />);
