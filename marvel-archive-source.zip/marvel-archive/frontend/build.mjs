import {build} from 'esbuild';
import {cp, mkdir} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
const root = fileURLToPath(new URL('.', import.meta.url));
await mkdir(root + 'dist', {recursive: true});
await build({absWorkingDir: root, entryPoints: ['src/main.jsx'], bundle: true, minify: true,
  jsx: 'automatic', outfile: 'dist/main.js', define: {'process.env.NODE_ENV': '"production"'}});
await cp(root + 'index.html', root + 'dist/index.html');
await cp(root + '../assets/marvel.jpg', root + 'dist/marvel.jpg');
await cp(root + '../assets/banners', root + 'dist/banners', {recursive: true});
