PRAGMA foreign_keys = ON;

-- 同一期号的不同扫描版、译本和合订本可以是不同 source。
CREATE TABLE IF NOT EXISTS sources (
    source_id TEXT PRIMARY KEY,
    sha256 TEXT NOT NULL UNIQUE CHECK(length(sha256) = 64),
    original_filename TEXT NOT NULL,
    stored_path TEXT NOT NULL,
    media_type TEXT NOT NULL CHECK(media_type IN ('pdf', 'cbz', 'image')),
    language TEXT,
    edition TEXT,
    imported_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS issues (
    issue_id TEXT PRIMARY KEY,
    series_title TEXT NOT NULL,
    series_start_year INTEGER,
    volume_label TEXT,
    issue_number TEXT NOT NULL,
    publication_date TEXT,
    universe TEXT,
    metadata_status TEXT NOT NULL DEFAULT 'unverified'
        CHECK(metadata_status IN ('unverified', 'verified'))
);

-- 页的唯一稳定定位是 source_id + file_page_index，索引从 1 开始。
-- CBZ 保留归档条目名；印刷页码允许未知，不能从文件序号冒充。
CREATE TABLE IF NOT EXISTS pages (
    page_id TEXT PRIMARY KEY,
    source_id TEXT NOT NULL REFERENCES sources(source_id),
    issue_id TEXT REFERENCES issues(issue_id),
    file_page_index INTEGER NOT NULL CHECK(file_page_index >= 1),
    archive_entry TEXT,
    printed_page_label TEXT,
    page_kind TEXT NOT NULL DEFAULT 'unknown'
        CHECK(page_kind IN ('unknown','cover','story','ad','credits','other')),
    image_path TEXT,
    image_sha256 TEXT,
    UNIQUE(source_id, file_page_index)
);

-- OCR 原文和模型推断分开存；bbox 使用 0–1 归一化坐标，顺序左上右下。
CREATE TABLE IF NOT EXISTS evidence (
    evidence_id TEXT PRIMARY KEY,
    page_id TEXT NOT NULL REFERENCES pages(page_id),
    panel_order INTEGER,
    evidence_kind TEXT NOT NULL
        CHECK(evidence_kind IN ('ocr','visual_description','human_note')),
    content TEXT NOT NULL,
    bbox_json TEXT,
    engine TEXT NOT NULL,
    engine_version TEXT,
    prompt_version TEXT,
    confidence REAL CHECK(confidence >= 0 AND confidence <= 1),
    review_status TEXT NOT NULL DEFAULT 'unreviewed'
        CHECK(review_status IN ('unreviewed','accepted','rejected')),
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- 检索摘要只是派生数据，必须可追溯到证据，不能自我证明。
CREATE TABLE IF NOT EXISTS chunks (
    chunk_id TEXT PRIMARY KEY,
    chunk_kind TEXT NOT NULL CHECK(chunk_kind IN ('panel','page','scene','issue')),
    content TEXT NOT NULL,
    pipeline_version TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS chunk_evidence (
    chunk_id TEXT NOT NULL REFERENCES chunks(chunk_id),
    evidence_id TEXT NOT NULL REFERENCES evidence(evidence_id),
    PRIMARY KEY(chunk_id, evidence_id)
);
CREATE INDEX IF NOT EXISTS pages_issue ON pages(issue_id);
CREATE INDEX IF NOT EXISTS evidence_page ON evidence(page_id);
