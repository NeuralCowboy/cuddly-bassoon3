"""Initialize the source catalog without downloading packages or models."""
from pathlib import Path
import sqlite3

ROOT = Path(__file__).resolve().parents[1]


def initialize(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(path) as connection:
        connection.executescript((ROOT / 'schemas' / 'catalog.sql').read_text(encoding='utf-8'))
        violations = connection.execute('PRAGMA foreign_key_check').fetchall()
        if violations:
            raise RuntimeError(f'Foreign key violations: {violations}')


if __name__ == '__main__':
    destination = ROOT / 'data' / 'indexes' / 'catalog.sqlite3'
    initialize(destination)
    print(f'来源数据库已就绪：{destination}')
