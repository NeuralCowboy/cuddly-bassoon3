from pathlib import Path
import tempfile
import unittest
import zipfile
from PIL import Image
import pymupdf
from marvel_kb.library import Library
from marvel_kb.engine import Engine


class FakeAPI:
    settings = {'base_url': 'http://localhost:9999/v1', 'embedding_model': 'test', 'chat_model': 'test'}
    calls = 0

    def embeddings(self, texts):
        self.calls += 1
        return [[float('钟楼' in t), float('信' in t), 1.] for t in texts]

    def chat(self, system, payload, model=None):
        if '你负责质疑' in system:
            return {'issues': []}
        return {'insufficient_evidence': False, 'claims': [
            {'text': '教学材料提到钟楼。', 'evidence_ids': [payload['evidence'][0]['evidence_id']]}]}


class LibraryTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.library = Library(self.root / 'data')
        self.image = self.root / 'page.png'
        Image.new('RGB', (100, 200), 'white').save(self.image)

    def tearDown(self):
        self.temp.cleanup()

    def seed(self):
        self.library.import_file(self.image, '教学系列', '1')
        page = self.library.pages()[0]
        self.library.save_extraction(page, {'ocr': '钟楼里有一封信', 'description': '人物站在钟楼'}, 'test')
        return page

    def test_import_dedup_restart_render(self):
        self.seed()
        self.assertIn('已存在', self.library.import_file(self.image, '其他', '2'))
        restored = Library(self.root / 'data')
        self.assertEqual(len(restored.pages()), 1)
        self.assertTrue(restored.render(restored.pages()[0]).startswith(b'\x89PNG'))
        self.assertEqual(len(restored.documents()), 2)

    def test_cbz_natural_order_and_pdf(self):
        archive = self.root / 'sample.cbz'
        with zipfile.ZipFile(archive, 'w') as z:
            for name in ['10.png', '2.png', '1.png']:
                z.write(self.image, name)
        self.library.import_file(archive, 'CBZ', '1')
        pages = self.library.pages()
        self.assertEqual([p['archive_entry'] for p in pages], ['1.png', '2.png', '10.png'])
        self.assertTrue(self.library.render(pages[0]).startswith(b'\x89PNG'))
        path = self.root / 'sample.pdf'
        with pymupdf.open() as pdf:
            pdf.new_page()
            pdf.save(path)
        self.library.import_file(path, 'PDF', '1')
        page = next(p for p in self.library.pages() if p['media_type'] == 'pdf')
        self.assertTrue(self.library.render(page).startswith(b'\x89PNG'))

    def test_cached_index_query_and_invalidation(self):
        page = self.seed()
        api = FakeAPI()
        engine = Engine(self.library, api)
        engine.index()
        calls = api.calls
        engine.index()
        self.assertEqual(calls, api.calls)
        result = engine.query('钟楼', mad=True)
        self.assertEqual(result['mode'], 'hybrid')
        self.assertEqual(len(result['mad']['trace']), 3)
        self.assertTrue(result['answer']['claims'])
        with self.library.db() as db:
            self.assertEqual(db.execute('SELECT count(*) FROM history').fetchone()[0], 1)
        self.library.save_extraction(page, {'ocr': '更正原文', 'description': ''}, 'test2')
        with self.assertRaisesRegex(ValueError, '索引不完整'):
            engine.query('钟楼')

    def test_unindexed_and_empty(self):
        self.assertEqual(Engine(self.library, FakeAPI()).query('测试')['evidence'], [])
        self.seed()
        with self.assertRaisesRegex(ValueError, '索引不完整'):
            Engine(self.library, FakeAPI()).query('钟楼')
        result = Engine(self.library, FakeAPI()).query('钟楼', hybrid=False, generate=False)
        self.assertTrue(result['evidence'])
        self.assertNotIn('answer', result)

    def test_zip_nested_images_ignore_macos(self):
        archive = self.root / 'images.zip'
        with zipfile.ZipFile(archive, 'w') as z:
            for name in ['chapter/10.png', 'chapter/2.png', '__MACOSX/._1.png']:
                z.write(self.image, name)
        self.library.import_file(archive, '图片包', '1')
        pages = self.library.pages()
        self.assertEqual([p['archive_entry'] for p in pages], ['chapter/2.png', 'chapter/10.png'])
        self.assertTrue(self.library.render(pages[0]).startswith(b'\x89PNG'))


if __name__ == '__main__':
    unittest.main()
