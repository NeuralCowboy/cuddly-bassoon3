import json
from pathlib import Path
import tempfile
import unittest

from marvel_kb.corpus import load_corpus
from marvel_kb.retrieval import BM25, DenseRetriever, Hit, cosine, rrf, search
from marvel_kb.mad import debate, validate_answer


class CoreTests(unittest.TestCase):
    def setUp(self):
        self.docs = load_corpus(Path(__file__).resolve().parents[1] / 'examples/demo.jsonl')

    def test_chinese_english_retrieval(self):
        for query in ('钟楼', 'clock tower'):
            self.assertEqual(BM25(self.docs).search(query)[0].evidence_id, 'demo-001')
        self.assertEqual(BM25(self.docs).search('振金潜艇'), [])

    def test_rrf_consensus_and_duplicates(self):
        a, b = Hit('a', 1000), Hit('b', .1)
        result = rrf([[a, b], [b]])
        self.assertEqual(result[0].evidence_id, 'b')
        self.assertAlmostEqual(rrf([[a, a]])[0].score, 1/61)

    def test_dense_uses_model_not_query_word_overlap(self):
        class FakeEmbedder:
            # 确定性测试夹具，不是生产语义模型。
            def encode_documents(self, texts):
                return [[1, 0], [0, 1], [-1, 0]]
            def encode_query(self, query):
                return [1, 0]
        hits = DenseRetriever(self.docs, FakeEmbedder()).search('no lexical overlap')
        self.assertEqual(hits[0].evidence_id, 'demo-001')
        with self.assertRaises(ValueError):
            cosine([1], [1, 2])

    def test_empty_corpus(self):
        self.assertEqual(search([], '任意问题')['results'], [])

    def test_reranker_controls_final_order(self):
        class ReverseReranker:
            def rerank(self, query, hits, documents):
                return list(reversed(hits))
        result = search(self.docs, '蜘蛛侠', reranker=ReverseReranker(), limit=1)
        self.assertEqual(result['results'][0], result['rrf'][-1])

    def test_bad_corpus(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'bad.jsonl'
            path.write_text('\n'.join(json.dumps(self.docs[0]) for _ in range(2)))
            with self.assertRaisesRegex(ValueError, '重复'):
                load_corpus(path)

    def test_fabricated_citation_rejected(self):
        answer = {'insufficient_evidence': False,
                  'claims': [{'text': '编造事实', 'evidence_ids': ['fake']}]}
        with self.assertRaisesRegex(ValueError, '编造'):
            validate_answer(answer, self.docs)

    def test_mad_passes_evidence_to_all_roles(self):
        calls = []
        def role(system, payload):
            calls.append(payload)
            if 'draft' in payload and 'review' not in payload:
                return {'issues': []}
            return {'insufficient_evidence': False,
                    'claims': [{'text': '教学样本中的情节', 'evidence_ids': ['demo-001']}]}
        result = debate('测试', self.docs, role, role, role)
        self.assertEqual(len(calls), 3)
        self.assertTrue(all(c['evidence'] == self.docs for c in calls))
        self.assertEqual(len(result['trace']), 3)

    def test_no_evidence_no_model_call(self):
        def forbidden(*args):
            raise AssertionError('不应调用模型')
        self.assertTrue(debate('未知', [], forbidden, forbidden, forbidden)['answer']['insufficient_evidence'])


if __name__ == '__main__':
    unittest.main()
