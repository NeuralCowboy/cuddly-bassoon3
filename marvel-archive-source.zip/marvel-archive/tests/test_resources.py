from pathlib import Path
import tempfile
import unittest
from marvel_kb.library import Library
from marvel_kb.resources import cards, save, search


class ResourceTests(unittest.TestCase):
    def test_card_title_and_source(self):
        html = '<a class="ComicCard__Url" href="/comics/issue/1/test"><p class="ComicCard__Info--title">A &amp; B #1</p></a>'
        self.assertEqual(list(cards(html)), [('https://share.marvel.com/comics/issue/1/test', 'A & B #1')])

    def test_catalog_is_not_story_evidence_and_is_idempotent(self):
        with tempfile.TemporaryDirectory() as temp:
            library = Library(Path(temp))
            row = dict(url='https://example.test/comic',title='Test #1',kind='free_issue',
                       access='未获取正文',discovered_from='https://example.test',checked_at='2026-11-03',
                       note='',local_source_id=None)
            save(library,[row]);save(library,[row])
            self.assertEqual(len(search(library,'Test')),1)
            self.assertEqual(library.documents(),[])
            self.assertEqual(library.pages(),[])
