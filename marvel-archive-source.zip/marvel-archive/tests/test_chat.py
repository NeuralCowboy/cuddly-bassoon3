"""原生聊天交互测试：不调用网络，不污染真实资料。"""
import os
os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
import tempfile
import time
import unittest
from pathlib import Path
from unittest.mock import patch
try:
    from PySide6.QtWidgets import QApplication
    from PySide6.QtCore import Qt
    from PySide6.QtTest import QTest
    from marvel_kb.desktop import Window
    from marvel_kb.library import Library
except ImportError:
    QApplication = None


@unittest.skipIf(QApplication is None, '需要 desktop 依赖')
class ChatTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.library = Library(Path(self.temp.name) / 'data')
        with patch('marvel_kb.desktop.Library', return_value=self.library):
            self.window = Window()
        self.window.show()
        self.app.processEvents()

    def tearDown(self):
        if self.window.task:
            self.window.task.wait(5000)
        self.window.close()
        self.app.processEvents()
        self.temp.cleanup()

    def test_enter_sends_empty_library_question(self):
        chat = self.window.chat
        chat.input.setPlainText('哪里能找到这个故事？')
        QTest.keyClick(chat.input, Qt.Key.Key_Return)
        for _ in range(40):
            self.app.processEvents()
            time.sleep(0.03)
            if self.window.result:
                break
        self.assertIn('尚无', self.window.result['message'])
        self.assertEqual(chat.input.toPlainText(), '')
        QTest.qWait(100)
        self.assertTrue(chat.send_button.isEnabled())
        self.assertEqual(len(self.window.turns), 2)

    def test_shift_enter_and_whitespace(self):
        chat = self.window.chat
        chat.input.setPlainText('第一行')
        QTest.keyClick(chat.input, Qt.Key.Key_End)
        QTest.keyClick(chat.input, Qt.Key.Key_Return, Qt.KeyboardModifier.ShiftModifier)
        self.assertIn('\n', chat.input.toPlainText())
        chat.input.setPlainText('   ')
        chat.send()
        self.assertIsNone(self.window.task)

    def test_attachment_saved_without_model(self):
        from PIL import Image
        path = Path(self.temp.name) / 'sample.png'
        Image.new('RGB', (30, 60)).save(path)
        self.window.preferences.fields['base_url'].clear()
        self.window.preferences.fields['chat_model'].clear()
        self.window.query('看看附件', [str(path)])
        for _ in range(50):
            self.app.processEvents()
            time.sleep(0.03)
            if self.window.result:
                break
        self.assertEqual(len(self.library.pages()), 1)
        self.assertIn('附件已保存', self.window.result['message'])

    def test_citation_navigates_original_page(self):
        from PIL import Image
        path = Path(self.temp.name) / 'page.png'
        Image.new('RGB', (30, 60)).save(path)
        self.library.import_file(path, '测试', '1')
        self.window.refresh()
        page = self.library.pages()[0]
        self.window.open_page(page['page_id'])
        self.assertEqual(self.window.tabs.currentIndex(), 1)
        self.assertEqual(self.window.pages.currentItem().data(Qt.ItemDataRole.UserRole)['page_id'], page['page_id'])

    def test_single_model_and_mandatory_mad(self):
        self.window.preferences.fields['base_url'].setText('https://example.test/v1')
        self.window.preferences.fields['chat_model'].setText('one-vision-model')
        settings = self.window.preferences.settings()
        self.assertEqual(settings['vision_model'], settings['chat_model'])
        self.assertTrue(all(not settings[k] for k in ('proposer_model', 'critic_model', 'judge_model')))
        with patch('marvel_kb.desktop.Engine') as factory:
            factory.return_value.query.return_value = {'question': '问题', 'message': '测试', 'evidence': []}
            with patch.object(self.window, 'run', side_effect=lambda fn, cb: cb(fn(lambda _: None))):
                self.window.query('问题', [])
            self.assertTrue(factory.return_value.query.call_args.kwargs['mad'])
            self.assertTrue(factory.return_value.query.call_args.kwargs['generate'])

    def test_carousel_changes_images_and_pauses(self):
        from marvel_kb.chat_ui import Artwork
        from PySide6.QtCore import QEvent
        banner = self.window.chat.findChild(Artwork)
        self.assertEqual(len(banner.slides), 7)
        before = banner.grab().toImage()
        banner.advance()
        banner.animation.setCurrentTime(banner.animation.duration())
        self.assertEqual(banner.current, 1)
        self.assertNotEqual(before, banner.grab().toImage())
        banner.go(len(banner.slides)-1)
        banner.animation.setCurrentTime(banner.animation.duration())
        banner.advance()
        banner.animation.setCurrentTime(banner.animation.duration())
        self.assertEqual(banner.current, 0)
        self.app.sendEvent(banner, QEvent(QEvent.Type.Enter))
        self.assertFalse(banner.timer.isActive())
        self.app.sendEvent(banner, QEvent(QEvent.Type.Leave))
        self.assertTrue(banner.timer.isActive())
        self.window.tabs.setCurrentIndex(0)
        self.app.processEvents()
        self.assertFalse(banner.timer.isActive())
