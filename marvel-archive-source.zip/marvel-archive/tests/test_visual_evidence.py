from io import BytesIO
from unittest import TestCase
from unittest.mock import Mock

from PIL import Image

from marvel_kb.visual_evidence import read_pages


class VisualEvidenceTests(TestCase):
    def test_model_reads_each_original_once_and_keeps_page_citations(self):
        image = BytesIO()
        Image.new('RGB', (20, 20), 'white').save(image, format='PNG')
        library = Mock()
        library.pages.return_value = [{'page_id': 'page-1'}, {'page_id': 'page-2'}]
        library.render.return_value = image.getvalue()
        api = Mock()
        api.chat.return_value = {'pages': [
            {'number': 2, 'observation': '第二页的画面'},
            {'number': 1, 'observation': '第一页的画面'},
        ]}
        evidence = [
            {'page_id': 'page-1', 'evidence_id': 'ocr-1', 'file_page_index': 1, 'text': '对白'},
            {'page_id': 'page-1', 'evidence_id': 'description-1', 'file_page_index': 1, 'text': '旧描述'},
            {'page_id': 'page-2', 'evidence_id': 'ocr-2', 'file_page_index': 2, 'text': '其他对白'},
        ]
        result, pages = read_pages(library, api, '总结故事', evidence)
        image_parts = [part for part in api.chat.call_args.args[1] if part['type'] == 'image_url']
        self.assertEqual(len(image_parts), 2)
        self.assertTrue(all(part['image_url']['url'].startswith('data:image/jpeg;base64,') for part in image_parts))
        self.assertEqual(pages, ['page-1', 'page-2'])
        self.assertEqual([row['text'] for row in result[-2:]], ['第一页的画面', '第二页的画面'])

    def test_incomplete_visual_response_fails_instead_of_claiming_coverage(self):
        image = BytesIO()
        Image.new('RGB', (20, 20), 'white').save(image, format='PNG')
        library = Mock()
        library.pages.return_value = [{'page_id': 'p'}]
        library.render.return_value = image.getvalue()
        api = Mock()
        api.chat.return_value = {'pages': []}
        with self.assertRaisesRegex(ValueError, '缺页'):
            read_pages(library, api, '总结故事',
                       [{'page_id': 'p', 'file_page_index': 1, 'text': '对白'}])


class StoryContextTests(TestCase):
    def test_story_context_fills_gap_within_the_same_comic(self):
        from marvel_kb.engine import Engine

        library, api = Mock(), Mock()
        api.settings = {}
        library.documents.return_value = [
            {'source_id': 'story', 'page_id': f'page-{page}', 'evidence_id': f'ocr-{page}',
             'file_page_index': page, 'text': '钟楼' if page in (1, 5) else '对白'}
            for page in range(1, 6)
        ] + [
            {'source_id': 'other', 'page_id': 'other-3', 'evidence_id': 'other-ocr',
             'file_page_index': 3, 'text': '无关对白'},
        ]
        result = Engine(library, api).query('钟楼', hybrid=False, generate=False)
        self.assertEqual([row['page_id'] for row in result['evidence']],
                         ['page-1', 'page-2', 'page-3', 'page-4', 'page-5'])
