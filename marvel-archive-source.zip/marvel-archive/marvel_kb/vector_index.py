"""向量缓存写入、校验和相似度检索。"""
from hashlib import sha256
import json
from .retrieval import Hit, cosine


def namespace(settings):
    return json.dumps([settings['base_url'], settings['embedding_model'], 'text-v1'])


class VectorIndex:
    def __init__(self, library, api):
        self.library, self.api = library, api

    def build(self, progress=lambda message: None):
        ns = namespace(self.api.settings)
        docs = self.library.documents()
        for start in range(0, len(docs), 16):
            batch = docs[start:start+16]
            with self.library.db() as db:
                pending = [d for d in batch if not db.execute(
                    'SELECT 1 FROM vectors WHERE evidence_id=? AND namespace=? AND content_hash=?',
                    (d['evidence_id'], ns, sha256(d['text'].encode()).hexdigest())).fetchone()]
            if pending:
                vectors = self.api.embeddings([d['text'] for d in pending])
                with self.library.db() as db:
                    db.executemany('INSERT OR REPLACE INTO vectors VALUES(?,?,?,?)', [
                        (d['evidence_id'], ns, sha256(d['text'].encode()).hexdigest(), json.dumps(v))
                        for d, v in zip(pending, vectors)])
            progress(f'建索引 {min(start+16,len(docs))}/{len(docs)}')
        return f'索引完成：{len(docs)} 条证据'

    def search(self, retrieval_query, docs):
        ns = namespace(self.api.settings)
        with self.library.db() as db:
            rows = {r['evidence_id']: r for r in db.execute('SELECT * FROM vectors WHERE namespace=?', (ns,))}
        if any(d['evidence_id'] not in rows or rows[d['evidence_id']]['content_hash'] !=
               sha256(d['text'].encode()).hexdigest() for d in docs):
            raise ValueError('当前模型索引不完整或已过期，请先建立向量索引；也可关闭混合检索')
        vector = self.api.embeddings([retrieval_query])[0]
        return sorted([Hit(d['evidence_id'], cosine(vector, json.loads(rows[d['evidence_id']]['vector'])))
                        for d in docs], key=lambda h: -h.score)[:40]
