"""原生桌面交互。后台任务通过 Qt 信号返回，UI 不执行耗时模型请求。"""
import json
from pathlib import Path
import sys
from PySide6.QtCore import Qt, QThread, Signal
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QLineEdit, QFileDialog, QTabWidget,
    QListWidget, QListWidgetItem, QSplitter, QMessageBox, QScrollArea,
    QDialog, QTextEdit, QDialogButtonBox)
from .library import Library, ROOT
from .providers import API
from .engine import Engine
from .chat_ui import ChatPanel, Artwork

from .settings_ui import SettingsPanel
from .workflow import extract_pages, research


class Task(QThread):
    done = Signal(object)
    failed = Signal(str)
    progress = Signal(str)

    def __init__(self, function):
        super().__init__()
        self.function = function

    def run(self):
        try:
            self.done.emit(self.function(self.progress.emit))
        except Exception as error:
            self.failed.emit(f'{type(error).__name__}: {error}')


class Window(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('MARVEL ARCHIVE · 单模型 MAD')
        self.resize(1240, 850)
        self.library, self.result, self.task = Library(), {}, None
        self.tabs = QTabWidget()
        self.setCentralWidget(self.tabs)
        self.actions = []
        self.preferences = SettingsPanel(self.export, self.statusBar().showMessage)
        self.tabs.addTab(self.preferences, '模型设置')
        self.library_tab()
        self.search_tab()
        from .resources_ui import panel
        self.tabs.addTab(panel(self.library), '在线资料')
        self.tabs.setCurrentIndex(2)
        self.statusBar().showMessage('本地资料库已就绪 · 未配置模型也可导入和预览')
        self.turns = []
        self.refresh()
        self.setStyleSheet("""
            QWidget{background:#10131a;color:#e7eaf0;font-family:'PingFang SC';font-size:14px;}
            QMainWindow,QTabWidget::pane{border:0;}
            QLabel{background:transparent;line-height:1.5;}
            QLineEdit,QTextBrowser,QListWidget,QTextEdit{background:#191f2a;border:1px solid #30394a;border-radius:8px;padding:10px;}
            QPushButton{background:#d52c40;border:0;border-radius:8px;padding:10px 18px;font-weight:600;}
            QPushButton:hover{background:#e64255;}
            QPushButton:disabled{background:#303644;color:#8d94a3;}
            QTabBar::tab{padding:14px 30px;background:#151a23;color:#9da7b8;}
            QTabBar::tab:selected{color:#fff;border-bottom:3px solid #e43c4e;}
            QTabWidget::pane{border-top:1px solid #262e3c;}
            QCheckBox{padding:8px;}
            QScrollArea,QScrollArea>QWidget>QWidget{background:#10131a;border:0;}
            QScrollBar:vertical{background:transparent;width:7px;}
            QScrollBar::handle:vertical{background:#3d4656;border-radius:3px;min-height:35px;}
            QScrollBar::add-line:vertical,QScrollBar::sub-line:vertical{height:0;}
            QFrame#welcome{background:#181e29;border:1px solid #2a3445;border-radius:16px;}
            QLabel#heroTitle{font-size:28px;font-weight:700;padding-top:12px;}
            QLabel#chatTitle{font-size:18px;font-weight:600;}
            QLabel#muted{color:#9ca8bb;font-size:13px;}
            QLabel#footnote{color:#7e8a9e;font-size:11px;}
            QLabel#messageRole{color:#b9c4d6;font-size:11px;font-weight:600;}
            QFrame#composer{background:#1b2230;border:1px solid #475166;border-radius:14px;}
            QPlainTextEdit{background:transparent;border:0;font-size:15px;}
            QFrame#userCard{background:#30212b;border:1px solid #583342;border-radius:14px;}
            QFrame#answerCard{background:#1a212d;border:1px solid #2d384b;border-radius:14px;}
            QPushButton#secondary,QPushButton#suggestion{background:#252e3d;color:#dce3ed;text-align:left;font-weight:400;}
            QPushButton#suggestion:hover,QPushButton#secondary:hover{background:#344056;}
            QPushButton#source{background:#253044;color:#b8d5ff;text-align:left;font-size:12px;font-weight:400;}
        """)

    def button(self, title, action, layout):
        button = QPushButton(title)
        button.clicked.connect(action)
        layout.addWidget(button)
        self.actions.append(button)
        return button

    def api(self):
        return API(self.preferences.settings(), self.preferences.key.text().strip())

    def library_tab(self):
        widget, layout = QWidget(), QVBoxLayout()
        widget.setLayout(layout)
        banner = Artwork(ROOT / 'assets/marvel.jpg')
        layout.addWidget(banner)
        layout.addWidget(QLabel('MARVEL ARCHIVE  /  私人漫画资料库\n从故事到证据，每一条回答都能找到原页。'))
        bar = QHBoxLayout()
        self.series, self.issue = QLineEdit(), QLineEdit()
        self.series.setMinimumWidth(0)
        self.issue.setMinimumWidth(0)
        self.series.setPlaceholderText('系列名（建议含起始年份）')
        self.issue.setPlaceholderText('期号；未知填“待核实”')
        bar.addWidget(self.series)
        bar.addWidget(self.issue)
        layout.addLayout(bar)
        bar = QHBoxLayout()
        self.button('导入漫画', self.import_files, bar)
        self.button('提取未处理页', self.extract, bar)
        self.button('建立向量索引', self.index, bar)
        self.button('校对当前页', self.edit_page, bar)
        layout.addLayout(bar)
        self.pages = QListWidget()
        self.pages.currentItemChanged.connect(self.preview)
        self.preview_label = QLabel('导入 PDF / CBZ / 图片后，在这里查看原页。')
        self.preview_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(self.preview_label)
        split = QSplitter()
        split.addWidget(self.pages)
        split.addWidget(scroll)
        split.setStretchFactor(1, 2)
        layout.addWidget(split, 1)
        self.count = QLabel()
        layout.addWidget(self.count)
        self.tabs.addTab(widget, '漫画书架')

    def search_tab(self):
        self.chat = ChatPanel(ROOT / 'assets/marvel.jpg')
        self.chat.submitted.connect(self.query)
        self.chat.reset_requested.connect(self.new_conversation)
        self.tabs.addTab(self.chat, '故事对话')

    def run(self, function, callback):
        if self.task and self.task.isRunning():
            return
        for button in self.actions:
            button.setEnabled(False)
        self.task = Task(function)
        self.task.progress.connect(self.statusBar().showMessage)
        self.task.progress.connect(self.chat.state.setText)
        self.task.done.connect(callback)
        self.task.failed.connect(self.task_failed)
        self.task.finished.connect(self.finished)
        self.statusBar().showMessage('正在处理……')
        self.task.start()

    def task_failed(self, message):
        self.chat.message('研究状态', '本次处理未完成：' + message + '\n已导入的文件和已提取的页面仍保存在本机，可重试。')
        self.statusBar().showMessage(message)

    def finished(self):
        self.chat.busy(False)
        for button in self.actions:
            button.setEnabled(True)
        self.refresh()
        self.statusBar().showMessage('任务结束；结果已写入本地。失败时已完成的页面可继续使用。')

    def refresh(self):
        self.pages.clear()
        pages = self.library.pages()
        for page in pages:
            item = QListWidgetItem(f'{page["series_title"]} #{page["issue_number"]} · '
                                   f'文件第 {page["file_page_index"]} 页 · ' +
                                   ('已提取' if page['extracted'] else '未提取'))
            item.setData(Qt.ItemDataRole.UserRole, page)
            self.pages.addItem(item)
        with self.library.db() as db:
            vectors = db.execute('SELECT count(*) FROM vectors').fetchone()[0]
        self.count.setText(f'{len(pages)} 页 · {len(self.library.documents())} 条证据 · {vectors} 条已存向量（含不同模型）')

    def preview(self, item, previous=None):
        if not item:
            return
        try:
            pix = QPixmap()
            pix.loadFromData(self.library.render(item.data(Qt.ItemDataRole.UserRole)))
            self.preview_label.setPixmap(pix.scaled(650, 850, Qt.AspectRatioMode.KeepAspectRatio,
                                                    Qt.TransformationMode.SmoothTransformation))
        except Exception as error:
            self.preview_label.setText(str(error))

    def import_files(self):
        paths, _ = QFileDialog.getOpenFileNames(self, '选择漫画或图片压缩包', '', '漫画 (*.pdf *.cbz *.zip *.png *.jpg *.jpeg *.webp)')
        if not paths:
            return
        series, issue = self.series.text().strip(), self.issue.text().strip()
        self.run(lambda progress: '\n'.join(self.library.import_file(p, series, issue) for p in paths),
                 lambda message: QMessageBox.information(self, '导入结果', message))

    def extract(self):
        pages = [p for p in self.library.pages() if not p['extracted']]
        if not pages:
            QMessageBox.information(self, '无需处理', '没有待提取页面。')
            return
        api = self.api()
        if not api.settings['vision_model'] or not api.settings['base_url']:
            QMessageBox.warning(self, '缺少配置', '先在模型设置填写接口地址和视觉模型。')
            return
        if QMessageBox.question(self, '确认提取', f'将 {len(pages)} 页发送到配置的模型接口。可能产生费用，是否开始？') != QMessageBox.StandardButton.Yes:
            return
        def work(progress):
            extract_pages(self.library, api, pages, progress)
            return '页面提取完成'
        self.run(work, lambda message: self.statusBar().showMessage(message))

    def edit_page(self):
        item = self.pages.currentItem()
        if not item:
            return
        page = item.data(Qt.ItemDataRole.UserRole)
        docs = [d for d in self.library.documents() if d['page_id'] == page['page_id']]
        dialog = QDialog(self)
        dialog.setWindowTitle('校对原文与画面描述 · 保存后需重新建向量索引')
        dialog.resize(650, 500)
        layout = QVBoxLayout(dialog)
        edits = {}
        for kind, title in [('ocr', '对白原文'), ('visual_description', '画面描述（推断）')]:
            layout.addWidget(QLabel(title))
            edit = QTextEdit(next((d['text'] for d in docs if d['evidence_kind'] == kind), ''))
            edits[kind] = edit
            layout.addWidget(edit)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        layout.addWidget(buttons)
        if dialog.exec():
            self.library.save_extraction(page, {'ocr': edits['ocr'].toPlainText(),
                                         'description': edits['visual_description'].toPlainText()}, 'human-reviewed')
            with self.library.db() as db:
                db.execute("UPDATE evidence SET review_status='accepted' WHERE page_id=?", (page['page_id'],))
            self.refresh()

    def index(self):
        api = self.api()
        if not api.settings['embedding_model']:
            QMessageBox.warning(self, '缺少配置', '先填写 Embedding 模型。')
            return
        self.run(lambda progress: Engine(self.library, api).index(progress),
                 lambda message: QMessageBox.information(self, '向量索引', message))

    def new_conversation(self):
        if not self.task or not self.task.isRunning():
            self.turns, self.result = [], {}
            self.chat.reset()

    def query(self, question, files):
        if self.task and self.task.isRunning():
            return
        api, history = self.api(), list(self.turns[-6:])
        configured = bool(api.settings['base_url'] and api.settings['chat_model'])
        options = dict(hybrid=self.preferences.hybrid.isChecked() and bool(api.settings['embedding_model']),
                       rerank=self.preferences.rerank.isChecked(), mad=True, generate=configured, visual=configured)
        self.chat.message('你', question + ('\n\n附件：' + '、'.join(Path(p).name for p in files) if files else ''))
        self.chat.accepted()
        self.chat.busy(True)
        def work(progress):
            return research(self.library, api, Engine(self.library, api),
                            question, files, history, options, progress)
        self.run(work, self.show_result)

    def show_result(self, result):
        self.result = result
        answer = result.get('answer')
        text = result.get('message')
        if not text:
            if answer:
                text = ('当前漫画里的剧情信息不足。' if answer['insufficient_evidence']
                        else '\n\n'.join(paragraph['text'] for paragraph in answer['claims']))
            elif result.get('evidence'):
                text = '已找到相关漫画内容。请配置主模型来阅读画格和对白，生成故事讲述。'
            else:
                text = '未找到相关漫画内容。'
        self.chat.message('研究员', text)
        self.turns.extend([{'role': 'user', 'content': result['question']},
                           {'role': 'assistant', 'content': text[:4000]}])

    def open_page(self, page_id):
        self.tabs.setCurrentIndex(1)
        for n in range(self.pages.count()):
            entry = self.pages.item(n)
            if entry.data(Qt.ItemDataRole.UserRole)['page_id'] == page_id:
                self.pages.setCurrentItem(entry)
                break

    def export(self):
        path, _ = QFileDialog.getSaveFileName(self, '导出结果与 MAD 记录', 'answer.json', 'JSON (*.json)')
        if path:
            Path(path).write_text(json.dumps(self.result, ensure_ascii=False, indent=2))

    def closeEvent(self, event):
        if self.task and self.task.isRunning():
            QMessageBox.information(self, '任务进行中', '请等待本次处理结束后关闭窗口，避免丢失处理中状态。')
            event.ignore()
        else:
            event.accept()


def main():
    app = QApplication(sys.argv)
    window = Window()
    window.show()
    sys.exit(app.exec())


if __name__ == '__main__':
    main()
