import Foundation
import Vision

do {
    let image = FileHandle.standardInput.readDataToEndOfFile()
    let request = VNRecognizeTextRequest()
    request.recognitionLevel = .accurate
    let supported = try request.supportedRecognitionLanguages()
    request.recognitionLanguages = ["zh-Hans", "zh-Hant", "en-US"].filter(supported.contains)
    try VNImageRequestHandler(data: image).perform([request])
    for line in request.results ?? [] {
        if let text = line.topCandidates(1).first?.string { print(text) }
    }
} catch {
    FileHandle.standardError.write(Data("\(error)\n".utf8))
    exit(1)
}
