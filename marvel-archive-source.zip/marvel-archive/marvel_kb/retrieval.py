"""第一课：BM25 -> embedding -> RRF -> cross-encoder。

只负责检索，不生成故事。索引先放内存，便于观察算法；大规模再换向量库。
"""
from collections import Counter
from dataclasses import dataclass
import math
import re


def tokenize(text):
    # 英文按词；中文用单字 + 相邻双字。教学基线，后续可替换成分词器。
    tokens = re.findall(r'[a-z0-9]+', text.lower())
    for run in re.findall(r'[\u4e00-\u9fff]+', text):
        tokens.extend(run)
        tokens.extend(run[i:i+2] for i in range(len(run)-1))
    return tokens


@dataclass(frozen=True)
class Hit:
    evidence_id: str
    score: float


class BM25:
    def __init__(self, documents, k1=1.5, b=0.75):
        self.ids = [d['evidence_id'] for d in documents]
        self.counts = [Counter(tokenize(d['text'])) for d in documents]
        self.lengths = [sum(c.values()) for c in self.counts]
        self.avg_length = sum(self.lengths) / max(1, len(self.lengths))
        self.df = Counter(t for c in self.counts for t in c)
        self.k1, self.b = k1, b

    def search(self, query, limit=40):
        results = []
        for eid, counts, length in zip(self.ids, self.counts, self.lengths):
            score = 0.0
            for term in set(tokenize(query)):
                tf = counts[term]
                if not tf:
                    continue
                df = self.df[term]
                idf = math.log(1 + (len(self.ids)-df+0.5)/(df+0.5))
                norm = 1-self.b+self.b*length/(self.avg_length or 1)
                score += idf * tf*(self.k1+1)/(tf+self.k1*norm)
            if score > 0:
                results.append(Hit(eid, score))
        return sorted(results, key=lambda h: (-h.score, h.evidence_id))[:limit]


def cosine(a, b):
    if len(a) != len(b):
        raise ValueError('向量维度不一致')
    denominator = math.sqrt(sum(x*x for x in a)*sum(y*y for y in b))
    return sum(x*y for x, y in zip(a, b))/denominator if denominator else 0.0


class DenseRetriever:
    """注入 embedder：同一模型分别编码文档和问题。"""
    def __init__(self, documents, embedder):
        self.ids = [d['evidence_id'] for d in documents]
        self.embedder = embedder
        self.vectors = embedder.encode_documents([d['text'] for d in documents]) if documents else []
        if len(self.vectors) != len(self.ids):
            raise ValueError('向量数量与文档数量不一致')

    def search(self, query, limit=40):
        if not self.ids:
            return []
        vector = self.embedder.encode_query(query)
        hits = [Hit(eid, cosine(vector, v)) for eid, v in zip(self.ids, self.vectors)]
        # 相似度只用于排序，不代表事实成立或模型置信度。
        return sorted(hits, key=lambda h: (-h.score, h.evidence_id))[:limit]


def rrf(rankings, k=60):
    """只融合名次，不直接相加不同尺度的检索分数。"""
    if k <= 0:
        raise ValueError('k 必须为正数')
    scores = Counter()
    for ranking in rankings:
        seen = set()
        for rank, hit in enumerate(ranking, start=1):
            if hit.evidence_id not in seen:
                scores[hit.evidence_id] += 1/(k+rank)
                seen.add(hit.evidence_id)
    return [Hit(eid, score) for eid, score in sorted(scores.items(), key=lambda x: (-x[1], x[0]))]


class SentenceEmbedder:
    """真实模型适配器。初始化时可能从 Hugging Face 下载模型。"""
    def __init__(self, model_name):
        from sentence_transformers import SentenceTransformer
        self.model = SentenceTransformer(model_name)

    def encode_documents(self, texts):
        return self.model.encode_document(texts, normalize_embeddings=True).tolist()

    def encode_query(self, text):
        return self.model.encode_query([text], normalize_embeddings=True)[0].tolist()


class CrossEncoderReranker:
    """联合读取问题与候选内容，比独立 embedding 更昂贵。"""
    def __init__(self, model_name):
        from sentence_transformers import CrossEncoder
        self.model = CrossEncoder(model_name)

    def rerank(self, query, hits, documents):
        if not hits:
            return []
        pairs = [(query, documents[h.evidence_id]['text']) for h in hits]
        scores = self.model.predict(pairs)
        results = [Hit(h.evidence_id, float(s)) for h, s in zip(hits, scores)]
        return sorted(results, key=lambda h: (-h.score, h.evidence_id))


def search(documents, query, embedder=None, reranker=None, limit=5):
    if limit < 1:
        raise ValueError('limit 必须为正整数')
    lexical = BM25(documents).search(query)
    dense = DenseRetriever(documents, embedder).search(query) if embedder else []
    fused = rrf([lexical, dense])
    by_id = {d['evidence_id']: d for d in documents}
    reranked = reranker.rerank(query, fused[:20], by_id) if reranker else fused
    return {'bm25': lexical, 'dense': dense, 'rrf': fused, 'results': reranked[:limit]}
