import argparse
from dataclasses import asdict
import json
from pathlib import Path

from .corpus import load_corpus
from .retrieval import search, SentenceEmbedder, CrossEncoderReranker
from .mad import debate, LocalChatClient


def main():
    parser = argparse.ArgumentParser(description='漫画知识库技术实验：检索与 MAD')
    parser.add_argument('query')
    parser.add_argument('--corpus', type=Path, default=Path('examples/demo.jsonl'))
    parser.add_argument('--embedding-model', help='Sentence Transformers 模型名或本地路径；可能下载模型')
    parser.add_argument('--reranker-model', help='单分数 CrossEncoder 模型名或本地路径')
    parser.add_argument('--mad-model', help='本机 Ollama 模型名：三个角色顺序调用同一模型')
    parser.add_argument('--top-k', type=int, default=3)
    args = parser.parse_args()
    documents = load_corpus(args.corpus)
    embedder = SentenceEmbedder(args.embedding_model) if args.embedding_model else None
    reranker = CrossEncoderReranker(args.reranker_model) if args.reranker_model else None
    result = search(documents, args.query, embedder, reranker, args.top_k)
    by_id = {d['evidence_id']: d for d in documents}
    evidence = [by_id[h.evidence_id] for h in result['results']]
    output = {'mode': 'hybrid' if embedder else 'bm25_only',
              'reranker': args.reranker_model,
              'rankings': {key: [asdict(h) for h in hits] for key, hits in result.items()},
              'evidence': evidence}
    if args.mad_model:
        client = LocalChatClient(args.mad_model)
        output['mad'] = debate(args.query, evidence, client, client, client)
        output['mad_model'] = args.mad_model
    print(json.dumps(output, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
