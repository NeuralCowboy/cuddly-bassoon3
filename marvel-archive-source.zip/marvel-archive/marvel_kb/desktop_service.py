"""桌面业务入口。模型、SQLite 和前端传输各自独立。"""
from base64 import b64encode
from io import BytesIO
from PIL import Image
from . import local_ocr, preferences, resources
from .engine import Engine
from .providers import API
from .workflow import extract_pages, research


class DesktopService:
    def __init__(self, library):
        self.library = library
        self.values = preferences.load()
        self.key = ''
        try:
            self.key = preferences.read_key()
        except Exception:
            pass

    def settings(self):
        return {**preferences.model_settings(self.values),
                'hybrid': bool(self.values.get('hybrid', True)),
                'rerank': bool(self.values.get('rerank', False)),
                'confirmCloudExtraction': bool(self.values.get('confirmCloudExtraction', False)),
                'remember': bool(self.values.get('remember', self.key)),
                'hasKey': bool(self.key)}

    def configure(self, values):
        settings = preferences.model_settings(values)
        if bool(settings['base_url']) != bool(settings['chat_model']):
            raise ValueError('请同时填写接口地址和模型。')
        settings.update(hybrid=bool(values.get('hybrid')), rerank=bool(values.get('rerank')))
        key = values.get('key', '').strip() or ('' if values.get('clearKey') else self.key)
        settings['confirmCloudExtraction'] = bool(values.get('confirmCloudExtraction', False))
        settings['remember'] = bool(key and values.get('remember'))
        preferences.save(settings, key, settings['remember'])
        self.values, self.key = settings, key
        return self.settings()

    def api(self):
        return API(preferences.model_settings(self.values), self.key)

    def test_model(self):
        api = self.api()
        if not (api.settings['base_url'] and api.settings['chat_model']):
            raise ValueError('请先保存接口地址和模型。')
        image = BytesIO()
        Image.new('RGB', (64, 64), 'blue').save(image, format='PNG')
        uri = 'data:image/png;base64,' + b64encode(image.getvalue()).decode()
        result = api.chat('识别图片的主色。只输出 JSON，color 字段使用英文颜色名。', [
            {'type': 'text', 'text': '这张图片的主色是什么？'},
            {'type': 'image_url', 'image_url': {'url': uri}},
        ])
        if not isinstance(result, dict) or str(result.get('color', '')).strip().lower() != 'blue':
            raise ValueError('接口有响应，但未通过读图测试。请检查模型是否支持图片。')

    def pages(self):
        fields = ('page_id', 'series_title', 'issue_number', 'file_page_index', 'extracted')
        return [{key: page[key] for key in fields} for page in self.library.pages()]

    def page(self, page_id):
        for page in self.library.pages():
            if page['page_id'] == page_id:
                return page
        raise ValueError('未找到该漫画页')

    def preview(self, page_id):
        page = self.page(page_id)
        docs = [d for d in self.library.documents() if d['page_id'] == page_id]
        return {'image': 'data:image/png;base64,' + b64encode(self.library.render(page)).decode(),
                'ocr': next((d['text'] for d in docs if d['evidence_kind'] == 'ocr'), ''),
                'description': next((d['text'] for d in docs if d['evidence_kind'] == 'visual_description'), '')}

    def correct(self, values):
        page = self.page(values['page_id'])
        self.library.save_extraction(page, {k: values[k] for k in ('ocr', 'description')}, 'human-reviewed')
        with self.library.db() as db:
            db.execute("UPDATE evidence SET review_status='accepted' WHERE page_id=?", (page['page_id'],))

    def extract(self, progress):
        api = self.api()
        if not (api.settings['base_url'] and api.settings['vision_model']):
            raise ValueError('请先设置接口地址与主模型')
        extract_pages(self.library, api, [p for p in self.library.pages() if not p['extracted']], progress)

    def extract_local(self, page_id, progress):
        pages = [self.page(page_id)] if page_id else self.library.pages()
        return local_ocr.extract(self.library, [p for p in pages if not p['extracted']], progress)

    def index(self, progress):
        api = self.api()
        if not (api.settings['base_url'] and api.settings['embedding_model']):
            raise ValueError('请先设置接口地址与 Embedding 模型')
        return Engine(self.library, api).index(progress)

    def ask(self, question, files, history, progress):
        api = self.api()
        configured = bool(api.settings['base_url'] and api.settings['chat_model'])
        options = dict(hybrid=configured and self.values.get('hybrid', True) and bool(api.settings['embedding_model']),
                       rerank=configured and self.values.get('rerank', False) and bool(api.settings['rerank_model']),
                       mad=True, generate=configured, visual=configured)
        return research(self.library, api, Engine(self.library, api), question, files, history, options, progress)

    def resources(self, term):
        return [{k: row[k] for k in ('title', 'access', 'url')} for row in resources.search(self.library, term)]
