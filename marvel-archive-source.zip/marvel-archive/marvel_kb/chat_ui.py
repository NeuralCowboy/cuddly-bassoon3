"""聊天组件：消息卡片、附件输入与滚动动画，不依赖知识库或模型。"""
from pathlib import Path
from PySide6.QtCore import Qt, Signal, QTimer, QPropertyAnimation, QEasingCurve
from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QScrollArea, QFrame, QPlainTextEdit, QFileDialog, QGraphicsOpacityEffect)

from .carousel import Artwork


class Composer(QPlainTextEdit):
    submitted = Signal()

    def keyPressEvent(self, event):
        if event.key() in (Qt.Key.Key_Return, Qt.Key.Key_Enter) and not event.modifiers() & Qt.KeyboardModifier.ShiftModifier:
            self.submitted.emit()
        else:
            super().keyPressEvent(event)


class ChatPanel(QWidget):
    submitted = Signal(str, list)
    reset_requested = Signal()

    def __init__(self, artwork):
        super().__init__()
        self.files, self.animations = [], []
        self.follow = False
        outer = QVBoxLayout(self)
        outer.setContentsMargins(24, 16, 24, 14)
        header = QHBoxLayout()
        title = QLabel('故事档案  /  与漫画对话')
        title.setObjectName('chatTitle')
        header.addWidget(title)
        header.addStretch()
        badge = QLabel('●  本地知识库')
        badge.setObjectName('muted')
        header.addWidget(badge)
        self.new_button = QPushButton('新对话')
        self.new_button.setObjectName('secondary')
        self.new_button.clicked.connect(self.reset_requested.emit)
        header.addWidget(self.new_button)
        outer.addLayout(header)
        self.root_layout, self.home = outer, True
        outer.addStretch(1)
        self.shell = QWidget()
        self.shell.setMaximumWidth(1100)
        stage = QHBoxLayout()
        stage.addStretch()
        stage.addWidget(self.shell, 1)
        stage.addStretch()
        outer.addLayout(stage)
        outer.addStretch(1)
        outer = QVBoxLayout(self.shell)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(12)
        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QFrame.Shape.NoFrame)
        self.canvas = QWidget()
        self.messages = QVBoxLayout(self.canvas)
        self.messages.setContentsMargins(0, 0, 0, 0)
        self.messages.setSpacing(20)
        self.messages.addStretch()
        self.scroll.setWidget(self.canvas)
        bar = self.scroll.verticalScrollBar()
        bar.rangeChanged.connect(lambda low, high: self.scroll_bottom() if self.follow else None)
        bar.sliderPressed.connect(lambda: setattr(self, 'follow', False))
        outer.addWidget(self.scroll, 1)
        self.welcome = QFrame()
        self.welcome.setObjectName('welcome')
        welcome = QVBoxLayout(self.welcome)
        welcome.setContentsMargins(12, 12, 12, 12)
        self.banner = Artwork(artwork)
        welcome.addWidget(self.banner)
        self.messages.insertWidget(0, self.welcome)
        self.state = QLabel('就绪 · 输入问题即可开始，Shift + Enter 换行')
        self.state.setObjectName('muted')
        outer.addWidget(self.state)
        composer = QFrame()
        composer.setObjectName('composer')
        box = QVBoxLayout(composer)
        box.setContentsMargins(16, 12, 16, 12)
        self.attachments = QLabel()
        self.attachments.setWordWrap(True)
        self.attachments.setObjectName('muted')
        self.attachments.hide()
        box.addWidget(self.attachments)
        self.input = Composer()
        self.input.setPlaceholderText('想找哪个故事？也可以附上漫画、图片或 ZIP…')
        self.input.setFixedHeight(66)
        self.input.setFrameShape(QFrame.Shape.NoFrame)
        self.input.submitted.connect(self.send)
        box.addWidget(self.input)
        controls = QHBoxLayout()
        self.attach = QPushButton('＋ 附加漫画')
        self.attach.setObjectName('secondary')
        self.attach.clicked.connect(self.pick_files)
        controls.addWidget(self.attach)
        self.clear = QPushButton('移除附件')
        self.clear.setObjectName('secondary')
        self.clear.clicked.connect(self.clear_files)
        controls.addWidget(self.clear)
        self.clear.hide()
        controls.addStretch()
        self.send_button = QPushButton('发送  ↑')
        self.send_button.clicked.connect(self.send)
        controls.addWidget(self.send_button)
        box.addLayout(controls)
        outer.addWidget(composer)
        tip = QLabel('附件会保存到本机；启用模型时，相关页面 / 文字会发送至你配置的接口。')
        tip.setObjectName('footnote')
        tip.setWordWrap(True)
        outer.addWidget(tip)
        self.scroll_animation = QPropertyAnimation(bar, b'value', self)
        self.scroll_animation.setDuration(240)
        self.scroll_animation.setEasingCurve(QEasingCurve.Type.OutCubic)
        self.set_home(True)

    def set_home(self, home):
        self.home = home
        self.root_layout.setStretch(1, 1 if home else 0)
        self.root_layout.setStretch(2, 0 if home else 1)
        self.root_layout.setStretch(3, 1 if home else 0)
        if home:
            self.banner.setFixedHeight(max(190, min(310, int(self.height()*0.36))))
            self.scroll.setFixedHeight(self.banner.height()+28)
        else:
            self.scroll.setMinimumHeight(0)
            self.scroll.setMaximumHeight(16777215)

    def resizeEvent(self, event):
        if hasattr(self, 'banner'):
            self.set_home(self.home)
        super().resizeEvent(event)

    def pick_files(self):
        paths, _ = QFileDialog.getOpenFileNames(self, '附加漫画', '', '漫画 (*.pdf *.cbz *.zip *.png *.jpg *.jpeg *.webp)')
        self.files = list(dict.fromkeys(self.files + paths))
        self.attachments.setText('附件：' + '  ·  '.join(Path(p).name for p in self.files))
        self.attachments.setVisible(bool(self.files))
        self.clear.setVisible(bool(self.files))

    def clear_files(self):
        self.files = []
        self.attachments.hide()
        self.clear.hide()

    def send(self):
        text = self.input.toPlainText().strip()
        if (not text and not self.files) or not self.send_button.isEnabled():
            return
        self.submitted.emit(text or '请读懂所附漫画的画格和对白，按情节讲述这个故事。', list(self.files))

    def accepted(self):
        self.input.clear()
        self.clear_files()

    def busy(self, value):
        for control in (self.send_button, self.attach, self.clear, self.input, self.new_button):
            control.setEnabled(not value)
        self.state.setText('正在检索与核对证据…' if value else '就绪 · 继续追问，或开始新的故事')

    def reset(self):
        for animation in self.animations:
            animation.stop()
        self.animations.clear()
        while self.messages.count() > 2:
            self.messages.takeAt(1).widget().deleteLater()
        self.welcome.show()
        self.set_home(True)
        self.follow = False
        self.scroll.verticalScrollBar().setValue(0)
        self.input.clear()
        self.clear_files()

    def scroll_bottom(self):
        if not hasattr(self, 'scroll_animation'):
            return
        bar = self.scroll.verticalScrollBar()
        self.scroll_animation.stop()
        self.scroll_animation.setStartValue(bar.value())
        self.scroll_animation.setEndValue(bar.maximum())
        self.scroll_animation.start()

    def message(self, role, text, animate=True):
        self.welcome.hide()
        self.set_home(False)
        self.follow = True
        row = QWidget()
        layout = QHBoxLayout(row)
        layout.setContentsMargins(0, 0, 0, 0)
        card = QFrame()
        card.setObjectName('userCard' if role == '你' else 'answerCard')
        body = QVBoxLayout(card)
        body.setContentsMargins(20, 16, 20, 16)
        label = QLabel(role.upper() if role == '你' else 'ARCHIVE  /  故事研究员')
        label.setObjectName('messageRole')
        body.addWidget(label)
        content = QLabel(text)
        content.setTextFormat(Qt.TextFormat.PlainText)
        content.setWordWrap(True)
        content.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        content.setMinimumWidth(180)
        body.addWidget(content)
        if role == '你':
            layout.addStretch(1)
            layout.addWidget(card, 4)
        else:
            layout.addWidget(card, 6)
            layout.addStretch(1)
        self.messages.insertWidget(self.messages.count()-1, row)
        if animate:
            effect = QGraphicsOpacityEffect(card)
            card.setGraphicsEffect(effect)
            animation = QPropertyAnimation(effect, b'opacity', card)
            animation.setDuration(260)
            animation.setStartValue(0.)
            animation.setEndValue(1.)
            self.animations.append(animation)
            animation.finished.connect(lambda: self.animations.remove(animation))
            animation.start()
        QTimer.singleShot(0, self.scroll_bottom)
