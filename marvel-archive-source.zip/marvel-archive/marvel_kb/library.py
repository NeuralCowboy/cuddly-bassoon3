"""原件入库、SQLite 来源目录、按需原页渲染；不含 UI 或模型调用。"""
from contextlib import contextmanager
from hashlib import sha256
from io import BytesIO
from pathlib import Path
import json
import re
import shutil
import sqlite3
import zipfile

ROOT = Path(__file__).resolve().parents[1]
IMAGES = {'.jpg', '.jpeg', '.png', '.webp'}


class Library:
    def __init__(self, root=ROOT / 'data'):
        self.root = Path(root)
        for name in ('originals', 'indexes', 'derived'):
            (self.root / name).mkdir(parents=True, exist_ok=True)
        with self.db() as db:
            db.executescript((ROOT / 'schemas/catalog.sql').read_text())
            db.executescript('''CREATE TABLE IF NOT EXISTS vectors (
                evidence_id TEXT REFERENCES evidence(evidence_id), namespace TEXT,
                content_hash TEXT, vector TEXT, PRIMARY KEY(evidence_id,namespace));
                CREATE TABLE IF NOT EXISTS history (
                id INTEGER PRIMARY KEY, created_at TEXT DEFAULT CURRENT_TIMESTAMP, payload TEXT);''')

    @contextmanager
    def db(self):
        with sqlite3.connect(self.root / 'indexes/catalog.sqlite3') as db:
            db.row_factory = sqlite3.Row
            db.execute('PRAGMA foreign_keys=ON')
            yield db

    def import_file(self, path, series, issue):
        _, message = self.import_source(path, series, issue)
        return message

    def import_source(self, path, series, issue):
        """导入原件并返回稳定来源 ID 与结果消息。"""
        path = Path(path)
        if not series.strip() or not issue.strip():
            raise ValueError('请填写系列和期号；不确定时明确写待核实')
        if path.suffix.lower() not in IMAGES | {'.pdf', '.cbz', '.zip'}:
            raise ValueError('支持 PDF、CBZ、ZIP 图片压缩包、JPG、PNG、WEBP；RAR/7z 请先转换为 ZIP')
        digest = sha256()
        with path.open('rb') as file:
            for block in iter(lambda: file.read(1024*1024), b''):
                digest.update(block)
        sid = digest.hexdigest()
        with self.db() as db:
            if db.execute('SELECT 1 FROM sources WHERE source_id=?', (sid,)).fetchone():
                return sid, '已存在：' + path.name
        if path.suffix.lower() == '.pdf':
            import pymupdf
            with pymupdf.open(path) as pdf:
                if pdf.needs_pass:
                    raise ValueError('请先解密 PDF')
                entries = [None] * len(pdf)
            kind = 'pdf'
        elif path.suffix.lower() in {'.cbz', '.zip'}:
            with zipfile.ZipFile(path) as archive:
                infos = [i for i in archive.infolist() if Path(i.filename).suffix.lower() in IMAGES
                         and not i.is_dir() and '__MACOSX' not in Path(i.filename).parts
                         and not Path(i.filename).name.startswith('.')]
                if any(i.file_size > 40*1024**2 for i in infos) or sum(i.file_size for i in infos) > 2*1024**3:
                    raise ValueError('归档展开体积超过限制')
                entries = [i.filename for i in sorted(infos, key=lambda i: [
                    (0, int(t)) if t.isdigit() else (1, t.lower()) for t in re.split(r'(\d+)', i.filename)])]
                if len(entries) != len(set(entries)):
                    raise ValueError('归档包含重复条目名')
            kind = 'cbz'
        else:
            entries, kind = [None], 'image'
        if not 0 < len(entries) <= 3000:
            raise ValueError('页数必须为 1–3000')
        target = self.root / 'originals' / (sid + path.suffix.lower())
        shutil.copyfile(path, target)
        iid = sha256((series + '\0' + issue).encode()).hexdigest()
        with self.db() as db:
            db.execute('INSERT OR IGNORE INTO issues(issue_id,series_title,issue_number) VALUES(?,?,?)', (iid, series, issue))
            db.execute('INSERT INTO sources(source_id,sha256,original_filename,stored_path,media_type) VALUES(?,?,?,?,?)',
                       (sid, sid, path.name, str(target.resolve()), kind))
            db.executemany('INSERT INTO pages(page_id,source_id,issue_id,file_page_index,archive_entry) VALUES(?,?,?,?,?)',
                           [(f'{sid}:{n}', sid, iid, n, entry) for n, entry in enumerate(entries, 1)])
        return sid, f'{path.name}：已导入 {len(entries)} 页'

    def pages(self):
        with self.db() as db:
            return [dict(r) for r in db.execute('''SELECT p.*, s.stored_path,s.media_type,s.original_filename,
                i.series_title,i.issue_number,
                (SELECT count(*) FROM evidence e WHERE e.page_id=p.page_id) AS extracted
                FROM pages p JOIN sources s USING(source_id) LEFT JOIN issues i USING(issue_id)
                ORDER BY s.imported_at,p.source_id,p.file_page_index''')]

    def render(self, page):
        from PIL import Image
        if page['media_type'] == 'pdf':
            import pymupdf
            with pymupdf.open(page['stored_path']) as pdf:
                p = pdf[page['file_page_index']-1]
                scale = min(2, 2000/max(p.rect.width, p.rect.height))
                return p.get_pixmap(matrix=pymupdf.Matrix(scale, scale)).tobytes('png')
        if page['media_type'] == 'cbz':
            with zipfile.ZipFile(page['stored_path']) as archive:
                raw = archive.read(page['archive_entry'])
        else:
            raw = Path(page['stored_path']).read_bytes()
        with Image.open(BytesIO(raw)) as image:
            image.thumbnail((2000, 2000))
            output = BytesIO()
            image.convert('RGB').save(output, format='PNG')
            return output.getvalue()

    def save_extraction(self, page, result, model):
        with self.db() as db:
            for kind, key in [('ocr', 'ocr'), ('visual_description', 'description')]:
                eid = page['page_id'] + ':' + kind
                db.execute('DELETE FROM vectors WHERE evidence_id=?', (eid,))
                db.execute('''INSERT INTO evidence(evidence_id,page_id,evidence_kind,content,engine,prompt_version)
                    VALUES(?,?,?,?,?,?) ON CONFLICT(evidence_id) DO UPDATE SET content=excluded.content,
                    engine=excluded.engine,review_status='unreviewed' ''',
                    (eid, page['page_id'], kind, result[key], model, 'vision-v1'))

    def documents(self):
        with self.db() as db:
            return [dict(r) for r in db.execute('''SELECT e.evidence_id,e.content AS text,e.evidence_kind,
                e.review_status,p.page_id,p.source_id,p.file_page_index,p.printed_page_label,
                s.original_filename AS source_file,i.series_title AS series,i.issue_number AS issue
                FROM evidence e JOIN pages p USING(page_id) JOIN sources s USING(source_id)
                LEFT JOIN issues i USING(issue_id) WHERE e.content<>'' AND e.review_status<>'rejected' ''')]

    def save_history(self, result):
        with self.db() as db:
            db.execute('INSERT INTO history(payload) VALUES(?)', (json.dumps(result, ensure_ascii=False),))
