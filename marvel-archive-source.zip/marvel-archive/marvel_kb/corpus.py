"""JSONL 是 OCR 与检索之间的接口；原始来源字段随内容一起流转。"""
import json
from pathlib import Path


def load_corpus(path):
    documents, seen = [], set()
    for number, line in enumerate(Path(path).read_text(encoding='utf-8').splitlines(), 1):
        if not line.strip():
            continue
        row = json.loads(line)
        for field in ('evidence_id', 'text', 'source_file', 'series', 'issue'):
            if not isinstance(row.get(field), str) or not row[field].strip():
                raise ValueError(f'第 {number} 行缺少非空字符串 {field}')
        page = row.get('file_page_index')
        if type(page) is not int or page < 1:
            raise ValueError(f'第 {number} 行页码必须是从 1 开始的整数')
        if row['evidence_id'] in seen:
            raise ValueError(f'重复 evidence_id: {row["evidence_id"]}')
        seen.add(row['evidence_id'])
        documents.append(row)
    return documents
