"""本地模型偏好与凭据。"""
import json
from .library import ROOT

CONFIG = ROOT / 'data/settings.json'
FIELDS = ('base_url', 'chat_model', 'embedding_model', 'rerank_model')


def load():
    return json.loads(CONFIG.read_text()) if CONFIG.exists() else {}


def model_settings(values):
    settings = {name: values.get(name, '').strip() for name in FIELDS}
    return dict(settings, vision_model=settings['chat_model'],
                proposer_model='', critic_model='', judge_model='')


def read_key():
    import keyring
    return keyring.get_password('marvel-archive', 'api-key') or ''


def save(values, key, remember):
    import keyring
    if remember and key:
        keyring.set_password('marvel-archive', 'api-key', key)
    else:
        try:
            keyring.delete_password('marvel-archive', 'api-key')
        except keyring.errors.PasswordDeleteError:
            pass
    CONFIG.parent.mkdir(parents=True, exist_ok=True)
    pending = CONFIG.with_suffix('.tmp')
    pending.write_text(json.dumps(values, ensure_ascii=False, indent=2))
    pending.replace(CONFIG)
