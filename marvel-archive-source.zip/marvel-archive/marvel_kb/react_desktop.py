"""将已打包的 React 界面嵌入 Qt 桌面窗口。"""
import json
import sys
from pathlib import Path
from uuid import uuid4
from PySide6.QtCore import QObject, QThread, QUrl, Signal, Slot
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import QApplication, QFileDialog, QMessageBox
from PySide6.QtWebChannel import QWebChannel
from PySide6.QtWebEngineCore import QWebEngineUrlRequestInterceptor
from PySide6.QtWebEngineWidgets import QWebEngineView
from .desktop_service import DesktopService
from .library import Library, ROOT

DIST = ROOT / 'frontend/dist'


class LocalFiles(QWebEngineUrlRequestInterceptor):
    def interceptRequest(self, info):
        url = info.requestUrl()
        allowed = url.toString() == 'qrc:///qtwebchannel/qwebchannel.js' or url.scheme() == 'data'
        if url.isLocalFile():
            allowed = Path(url.toLocalFile()).resolve().is_relative_to(DIST)
        info.block(not allowed)


class Job(QThread):
    progress = Signal(str)

    def __init__(self, function):
        super().__init__()
        self.function = function

    def run(self):
        try:
            self.result = json.dumps(self.function(self.progress.emit), ensure_ascii=False), ''
        except Exception as error:
            self.result = 'null', str(error) or type(error).__name__


class Bridge(QObject):
    completed = Signal(str, str, str)
    progress = Signal(str)

    def __init__(self, window, service):
        super().__init__(window)
        self.window, self.service = window, service
        self.picked, self.job, self.last = {}, None, None

    @Slot(result=str)
    def choose(self):
        paths, _ = QFileDialog.getOpenFileNames(self.window, '选择漫画', '', '漫画 (*.pdf *.cbz *.zip *.png *.jpg *.jpeg *.webp)')
        picked = {uuid4().hex: Path(path) for path in paths}
        self.picked.update(picked)
        return json.dumps([{'id': key, 'name': path.name} for key, path in picked.items()])

    @Slot(str, str, str)
    def request(self, request_id, action, payload):
        if self.job is not None:
            self.completed.emit(request_id, 'null', '请等待当前任务结束')
            return
        try:
            data = json.loads(payload)
            if action == 'export':
                if self.last is None:
                    raise ValueError('尚无回答可导出')
                path, _ = QFileDialog.getSaveFileName(self.window, '导出回答', 'answer.json', 'JSON (*.json)')
                if path:
                    Path(path).write_text(json.dumps(self.last, ensure_ascii=False, indent=2))
                self.completed.emit(request_id, 'null', '')
                return
            if action == 'open':
                url = QUrl(data['url'])
                if url.scheme() != 'https':
                    raise ValueError('仅支持打开 HTTPS 来源')
                QDesktopServices.openUrl(url)
                self.completed.emit(request_id, 'null', '')
                return
            self.job = Job(lambda progress: self.dispatch(action, data, progress))
            self.job.progress.connect(self.progress)
            self.request_id = request_id
            self.job.finished.connect(self.finished)
            self.job.start()
        except Exception as error:
            self.completed.emit(request_id, 'null', str(error))

    @Slot()
    def finished(self):
        job, self.job = self.job, None
        job.deleteLater()
        self.completed.emit(self.request_id, *job.result)

    def dispatch(self, action, data, progress):
        service = self.service
        if action == 'import':
            for token in data['files']:
                service.library.import_file(self.picked[token], data['series'], data['issue'])
            return service.pages()
        if action == 'ask':
            files = [self.picked[token] for token in data['files']]
            self.last = service.ask(data['question'], files, data['history'], progress)
            return self.last
        operations = {
            'settings': service.settings, 'save': lambda: service.configure(data), 'testModel': service.test_model,
            'pages': service.pages, 'preview': lambda: service.preview(data['page_id']),
            'correct': lambda: service.correct(data), 'extract': lambda: service.extract(progress),
            'index': lambda: service.index(progress),
            'extractLocal': lambda: service.extract_local(data.get('page_id'), progress),
            'resources': lambda: service.resources(data.get('term', '')),
        }
        if action not in operations:
            raise ValueError('未知桌面操作')
        return operations[action]()


class Window(QWebEngineView):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('MARVEL ARCHIVE · 漫威故事库')
        self.resize(1240, 850)
        self.interceptor = LocalFiles(self)
        self.page().setUrlRequestInterceptor(self.interceptor)
        self.bridge = Bridge(self, DesktopService(Library()))
        self.channel = QWebChannel(self.page())
        self.channel.registerObject('archive', self.bridge)
        self.page().setWebChannel(self.channel)
        self.load(QUrl.fromLocalFile(str(DIST / 'index.html')))

    def closeEvent(self, event):
        if self.bridge.job is not None:
            event.ignore()
            QMessageBox.information(self, '任务进行中', '请等待当前任务结束。')
        else:
            super().closeEvent(event)


def main():
    app = QApplication(sys.argv)
    if not (DIST / 'index.html').exists():
        QMessageBox.critical(None, '前端尚未构建', '请在项目目录执行 cd frontend，然后执行 npm ci 和 npm run build。')
        return
    window = Window()
    window.show()
    window.raise_()
    window.activateWindow()
    sys.exit(app.exec())


if __name__ == '__main__':
    main()
