"""公开资料目录页：明确区分来源线索与已入库正文。"""
from PySide6.QtCore import Qt, QUrl
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel, QLineEdit, QListWidget, QListWidgetItem
from . import resources


def panel(library):
    widget = QWidget()
    layout = QVBoxLayout(widget)
    layout.setContentsMargins(28, 24, 28, 24)
    layout.addWidget(QLabel('在线资料目录 · 双击打开来源网页'))
    layout.addWidget(QLabel('这些是查找漫画的线索，不是已获得的漫画正文，不参与故事问答。'))
    query = QLineEdit()
    query.setPlaceholderText('搜索英文系列名，例如 Spider-Man、Avengers、X-Men…')
    layout.addWidget(query)
    count = QLabel()
    listing = QListWidget()
    layout.addWidget(count)
    layout.addWidget(listing)
    def update(text=''):
        listing.clear()
        rows = resources.search(library, text)
        with library.db() as db:
            total = db.execute('SELECT count(*) FROM external_resources').fetchone()[0]
        count.setText(f'来源总计 {total} 条 · 当前显示 {len(rows)} 条（最多 500，输入名称缩小范围）')
        for row in rows:
            item = QListWidgetItem(row['title'] + '\n' + row['access'])
            item.setToolTip(row['note'] + '\n' + row['url'])
            item.setData(Qt.ItemDataRole.UserRole, row['url'])
            listing.addItem(item)
    query.textChanged.connect(update)
    listing.itemDoubleClicked.connect(lambda item: QDesktopServices.openUrl(QUrl(item.data(Qt.ItemDataRole.UserRole))))
    update()
    return widget
