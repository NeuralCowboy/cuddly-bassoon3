"""原生图片轮播：多图滑入切换、定时播放、悬停暂停。"""
from pathlib import Path
from PySide6.QtCore import Qt, QTimer, QPropertyAnimation, QEasingCurve, Property, QAbstractAnimation
from PySide6.QtGui import QPixmap, QPainter
from PySide6.QtWidgets import QWidget, QPushButton, QSizePolicy


class Artwork(QWidget):
    def __init__(self, path):
        super().__init__()
        path = Path(path)
        paths = [path] + sorted((path.parent / 'banners').glob('*'))
        self.slides = [(p, QPixmap(str(p))) for p in paths if p.suffix.lower() in ('.jpg', '.png', '.webp')]
        self.slides = [(p, pix) for p, pix in self.slides if not pix.isNull()]
        self.backgrounds = [pix.toImage().pixelColor(0, 0) for _, pix in self.slides]
        self.current, self.target, self._progress, self._frames = 0, 0, 0., {}
        self.setFixedHeight(170)
        self.setMinimumWidth(0)
        self.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Fixed)
        self.animation = QPropertyAnimation(self, b'progress', self)
        self.animation.setDuration(650)
        self.animation.setStartValue(0.)
        self.animation.setEndValue(1.)
        self.animation.setEasingCurve(QEasingCurve.Type.InOutCubic)
        self.animation.finished.connect(self.complete)
        self.timer = QTimer(self)
        self.timer.setInterval(4500)
        self.timer.timeout.connect(self.advance)
        self.dots = []
        for index in range(len(self.slides)):
            dot = QPushButton('●', self)
            dot.setAccessibleName(f'第 {index+1} 张图片')
            dot.setCursor(Qt.CursorShape.PointingHandCursor)
            dot.clicked.connect(lambda checked=False, i=index: self.go(i))
            self.dots.append(dot)
        self.update_dots()

    def set_progress(self, value):
        self._progress = value
        self.update()

    progress = Property(float, lambda self: self._progress, set_progress)

    def update_dots(self):
        for i, dot in enumerate(self.dots):
            color = '#ffffff' if i == self.target else '#788396'
            dot.setStyleSheet(f'background:rgba(10,14,22,160);color:{color};border:0;border-radius:10px;padding:0;font-size:10px;')

    def advance(self):
        if self.slides:
            self.go((self.current+1) % len(self.slides))

    def go(self, index):
        if not 0 <= index < len(self.slides) or index == self.current or self.animation.state() == QAbstractAnimation.State.Running:
            return
        self.target = index
        self.update_dots()
        self.animation.start()
        self.timer.start() if self.isVisible() and not self.underMouse() else self.timer.stop()

    def complete(self):
        self.current = self.target
        self._progress = 0.
        self.update()

    def resizeEvent(self, event):
        self._frames.clear()
        start = (self.width()-len(self.dots)*24)//2
        for index, dot in enumerate(self.dots):
            dot.setGeometry(start+index*24, self.height()-28, 20, 20)
        super().resizeEvent(event)

    def showEvent(self, event):
        super().showEvent(event)
        if self.animation.state() == QAbstractAnimation.State.Paused:
            self.animation.resume()
        if len(self.slides) > 1 and not self.underMouse():
            self.timer.start()

    def hideEvent(self, event):
        self.timer.stop()
        if self.animation.state() == QAbstractAnimation.State.Running:
            self.animation.pause()
        super().hideEvent(event)

    def enterEvent(self, event):
        self.timer.stop()
        super().enterEvent(event)

    def leaveEvent(self, event):
        if self.isVisible() and len(self.slides) > 1:
            self.timer.start()
        super().leaveEvent(event)

    def frame(self, index):
        if index not in self._frames:
            path, image = self.slides[index]
            # 盾牌完整展示，其余横幅按等比铺满；图片自身不再平移。
            mode = Qt.AspectRatioMode.KeepAspectRatio if 'captain' in path.name else Qt.AspectRatioMode.KeepAspectRatioByExpanding
            self._frames[index] = image.scaled(self.size(), mode, Qt.TransformationMode.SmoothTransformation)
        return self._frames[index]

    def paintEvent(self, event):
        if not self.slides:
            return
        painter = QPainter(self)
        indices = [(self.current, 0)]
        if self.target != self.current:
            indices = [(self.current, -int(self.width()*self._progress)),
                       (self.target, int(self.width()*(1-self._progress)))]
        for index, shift in indices:
            painter.save()
            painter.setClipRect(shift, 0, self.width(), self.height())
            painter.fillRect(shift, 0, self.width(), self.height(), self.backgrounds[index])
            pix = self.frame(index)
            painter.drawPixmap(shift+(self.width()-pix.width())//2,
                               int((self.height()-pix.height())*0.3), pix)
            painter.restore()
