"""从漫画图片离线提取文字，保留页码和人工校对状态。"""
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory


def extract(library, pages, progress):
    if not pages:
        return '没有待提取页面'
    if sys.platform != 'darwin':
        raise RuntimeError('本地 OCR 需要 macOS 和 Apple 命令行工具')
    recognized = 0
    with TemporaryDirectory(prefix='marvel-ocr-') as directory:
        work = Path(directory)
        executable = work / 'recognize'
        compiler = subprocess.run(
            ['/usr/bin/swiftc', '-module-cache-path', str(work / 'cache'),
             str(Path(__file__).with_name('recognize.swift')), '-o', str(executable)],
            capture_output=True, text=True, timeout=120)
        if compiler.returncode:
            raise RuntimeError('无法编译本地 OCR：' + compiler.stderr.strip())
        for index, page in enumerate(pages, 1):
            progress(f'本地 OCR {index}/{len(pages)} 页')
            result = subprocess.run([str(executable)], input=library.render(page),
                                    capture_output=True, timeout=60)
            if result.returncode:
                raise RuntimeError(f'文件第 {page["file_page_index"]} 页识别失败：' +
                                   result.stderr.decode(errors='replace').strip())
            text = result.stdout.decode().strip()
            if text:
                library.save_extraction(page, {'ocr': text, 'description': ''}, 'apple-vision')
                recognized += 1
    return f'已检查 {len(pages)} 页，识别到文字 {recognized} 页'
