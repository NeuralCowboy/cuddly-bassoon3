"""外部目录与下载来源；不作为漫画正文证据。"""
from datetime import datetime, timezone
from html import unescape
import json
import re
from urllib.parse import urljoin

SCHEMA = '''CREATE TABLE IF NOT EXISTS external_resources (
    url TEXT PRIMARY KEY, title TEXT NOT NULL, kind TEXT NOT NULL,
    access TEXT NOT NULL, discovered_from TEXT NOT NULL, checked_at TEXT NOT NULL,
    note TEXT NOT NULL DEFAULT '', local_source_id TEXT)'''


def cards(html, base='https://share.marvel.com'):
    pattern = r'<a\b[^>]*class="ComicCard__Url"[^>]*href="([^"]+)"[^>]*>(.*?)</a>'
    for link, body in re.findall(pattern, html, re.S):
        match = re.search(r'<p\b[^>]*class="ComicCard__Info--title"[^>]*>(.*?)</p>', body, re.S)
        if match:
            title = unescape(re.sub('<[^>]+>', '', match[1])).strip()
            if title:
                yield urljoin(base, unescape(link)), title


def save(library, rows):
    with library.db() as db:
        db.executescript(SCHEMA)
        db.executemany('''INSERT INTO external_resources
            (url,title,kind,access,discovered_from,checked_at,note,local_source_id)
            VALUES(:url,:title,:kind,:access,:discovered_from,:checked_at,:note,:local_source_id)
            ON CONFLICT(url) DO UPDATE SET title=excluded.title,access=excluded.access,
            checked_at=excluded.checked_at,note=excluded.note''', rows)


def search(library, query=''):
    with library.db() as db:
        db.executescript(SCHEMA)
        return [dict(r) for r in db.execute('''SELECT * FROM external_resources WHERE title LIKE ?
            ORDER BY CASE kind WHEN 'downloaded_promo' THEN 0 WHEN 'free_issue' THEN 1 ELSE 2 END,title LIMIT 500''',
            ('%'+query+'%',))]


def build_catalog(library, directory):
    now = datetime.now(timezone.utc).isoformat()
    rows = {}
    def add(url, title, kind, access, source, note=''):
        rows[url] = dict(url=url, title=title, kind=kind, access=access,
                         discovered_from=source, checked_at=now, note=note, local_source_id=None)
    series_html = (directory/'series.html').read_text()
    series_links = re.findall(r'<a\b[^>]*href="(/comics/series/[^"#]+)"[^>]*>(.*?)</a>', series_html, re.S)
    for link, body in series_links:
        url = urljoin('https://share.marvel.com', unescape(link))
        title = unescape(re.sub('<[^>]+>', '', body)).strip()
        if not title:
            continue
        add(url, title, 'series', '目录信息；未获取正文', 'https://share.marvel.com/comics/series',
            '官方系列目录快照；不是单期漫画，不证明当前阅读或下载权限。')
    for url, title in cards((directory/'free-issues.html').read_text()):
        add(url, title, 'free_issue', '官方标为免费阅读；未获取正文',
            'https://share.marvel.com/comics/discover/2421/get-started-with-free-issues')
    html = (directory/'marvel-comics.html').read_text()
    section = html.split('Read For Free</h2>', 1)
    if len(section) == 2:
        for url, title in cards(section[1].split('<h2', 1)[0]):
            add(url, title, 'free_issue', '官方清单标为免费；阅读与下载待核验', 'https://share.marvel.com/comics',
                '页面访问结果不一致，可能有缓存或历史状态；不承诺当前无需登录即可阅读。')
    save(library, list(rows.values()))
    (directory/'official-catalog.json').write_text(json.dumps(list(rows.values()), ensure_ascii=False, indent=2))
    return rows
