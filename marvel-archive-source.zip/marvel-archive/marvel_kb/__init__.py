"""Small, inspectable retrieval and evidence verification components."""
