"""模型设置面板与钥匙串读写。"""
from PySide6.QtWidgets import (QWidget, QVBoxLayout, QFormLayout, QLabel, QLineEdit,
    QCheckBox, QPushButton, QScrollArea, QMessageBox)
from . import preferences
FIELDS = {'base_url': '接口地址', 'chat_model': '主模型（支持图片）'}
ADVANCED = {'embedding_model': 'Embedding 模型', 'rerank_model': '重排模型'}


class SettingsPanel(QWidget):
    def __init__(self, export, notify):
        super().__init__()
        self.notify = notify
        widget, layout = QWidget(), QFormLayout()
        widget.setLayout(layout)
        heading = QLabel('连接一个模型，开始研究漫画。')
        heading.setObjectName('heroTitle')
        layout.addRow(heading)
        note = QLabel('主模型负责读图与问答。MAD 始终启用：整理 → 核验 → 裁决。\n'
                      '三个角色使用同一模型，分别检查证据；结果仍需以原页为准。')
        note.setWordWrap(True)
        layout.addRow(note)
        saved = preferences.load()
        self.fields = {}
        for key, title in FIELDS.items():
            field = QLineEdit(saved.get(key, ''))
            field.setPlaceholderText('请输入模型或地址' if key != 'base_url' else 'https://your-provider.example/v1')
            self.fields[key] = field
            layout.addRow(title, field)
        self.key = QLineEdit()
        self.key.setEchoMode(QLineEdit.EchoMode.Password)
        self.key.setPlaceholderText('API Key；可不保存，仅本次会话使用')
        try:
            self.key.setText(preferences.read_key())
        except Exception:
            pass
        layout.addRow('API Key', self.key)
        self.remember = QCheckBox('保存密钥到系统钥匙串')
        layout.addRow(self.remember)
        save = QPushButton('保存设置')
        save.clicked.connect(self.save_settings)
        layout.addRow(save)
        badge = QLabel('✓  MAD 核验已开启 · 每次模型回答都经过三个角色处理')
        badge.setObjectName('muted')
        layout.addRow(badge)
        toggle = QPushButton('高级检索设置  ▾')
        toggle.setObjectName('secondary')
        self.advanced = QWidget()
        self.advanced_form = QFormLayout(self.advanced)
        for key, title in ADVANCED.items():
            field = QLineEdit(saved.get(key, ''))
            field.setPlaceholderText('可选；不填写时使用关键词检索')
            self.fields[key] = field
            self.advanced_form.addRow(title, field)
        self.advanced.hide()
        toggle.clicked.connect(lambda: self.advanced.setVisible(not self.advanced.isVisible()))
        layout.addRow(toggle)
        layout.addRow(self.advanced)
        layout.addRow(QLabel('资料保存在本机；执行模型任务时，相关内容会发送到所填接口。'))
        layout.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow)
        layout.setContentsMargins(32, 24, 32, 24)
        layout.setVerticalSpacing(16)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(widget)
        container = QVBoxLayout(self)
        container.setContentsMargins(0, 0, 0, 0)
        container.addWidget(scroll)
        self.hybrid = QCheckBox('混合检索')
        self.rerank = QCheckBox('重排序')
        for key, checkbox, default in [('hybrid', self.hybrid, True), ('rerank', self.rerank, False)]:
            checkbox.setChecked(saved.get(key, default))
            self.advanced_form.addRow(checkbox)
        export_button = QPushButton('导出最近一次回答与研究记录')
        export_button.clicked.connect(export)
        self.advanced_form.addRow(export_button)

    def save_settings(self):
        try:
            settings = self.settings()
            settings.update(hybrid=self.hybrid.isChecked(), rerank=self.rerank.isChecked(), mad=True, generate=True)
            preferences.save(settings, self.key.text(), self.remember.isChecked())
            self.notify('设置已保存')
        except Exception as error:
            QMessageBox.warning(self, '设置保存失败', str(error))

    def settings(self):
        return preferences.model_settings({key: field.text() for key, field in self.fields.items()})
