"""书架与聊天共用的页面提取流程，不依赖桌面界面。"""
from pathlib import Path


def extract_pages(library, api, pages, progress, label='视觉提取'):
    for number, page in enumerate(pages, 1):
        progress(f'{label} {number}/{len(pages)} 页')
        result = api.extract(library.render(page))
        library.save_extraction(page, result, api.settings['vision_model'])


def research(library, api, engine, question, files, history, options, progress):
    source_ids = set()
    for file in files:
        path = Path(file)
        progress('正在导入附件：' + path.name)
        source_id, _ = library.import_source(path, path.stem + '（待核实）', '待核实')
        source_ids.add(source_id)
    if source_ids:
        pending = [p for p in library.pages() if p['source_id'] in source_ids and not p['extracted']]
        if pending and not (api.settings['base_url'] and api.settings['vision_model']):
            return {'question': question, 'message': '附件已保存到书架。请先在模型设置填写视觉模型与接口，'
                    '再发送同一附件即可继续提取；也可以在书架中手动校对录入。', 'evidence': []}
        extract_pages(library, api, pending, progress, label='正在阅读附件')
    if options['hybrid']:
        engine.index(progress)
    return engine.query(question, **options, history=history, source_ids=source_ids or None, progress=progress)
