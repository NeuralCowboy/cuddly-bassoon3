#!/bin/zsh
cd "${0:A:h}"
if [[ ! -x .venv/bin/python ]]; then
  echo '请先执行：python3 -m venv .venv，然后 .venv/bin/python -m pip install -e ".[desktop]"'
  read
  exit 1
fi
.venv/bin/python -m marvel_kb.react_desktop
