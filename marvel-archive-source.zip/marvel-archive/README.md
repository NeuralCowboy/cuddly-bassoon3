# MARVEL ARCHIVE · 本地漫画知识库

原生桌面应用：本地原件与 SQLite 来源目录、PDF/CBZ/ZIP 图片包导入、逐页预览、视觉 OCR 与描述分离、人工校对、持久化 embedding、BM25 + 向量 + RRF、可选重排、邻页展开、图文剧情理解与 MAD 核验。

## 启动

安装下方依赖后，macOS 用户可以双击 **启动漫画库.command**，也可以运行：

```sh
.venv/bin/python -m marvel_kb.react_desktop
```

全新环境：

```sh
python3 -m venv .venv
.venv/bin/python -m pip install -e '.[desktop]'
(cd frontend && npm ci && npm run build)
```

在桌面“模型设置”中输入接口、密钥与模型，不需要编辑代码。漫画可以后补；空库不注入演示数据。模型内容发送范围、压缩包支持和使用说明见 [桌面版使用](docs/桌面版使用.md)。

## 验证与学习

```sh
.venv/bin/python -m unittest discover -s tests -v
python3 -m marvel_kb '蜘蛛侠在哪里找到信？'
```

第二条是独立教学 CLI，使用虚构样本，绝不作为真实 Marvel 出处；桌面版只查询你的实际资料。在「模型设置」保存自己的配置后，可用「测试连接」验证读图。

[建设方案](docs/建设方案.md) · [代码学习路线](docs/代码学习路线.md) · [主题图片来源](assets/SOURCES.md)


## 模块边界

- `frontend/src/` 按故事对话、轮播、书架、在线目录和设置拆分 React 组件。`bridge.js` 管理异步请求。
- `react_desktop.py` 管理 Qt 窗口、文件选择与本地 IPC。`desktop_service.py` 编排用户操作。`preferences.py` 管理本地偏好和钥匙串。
- `library.py` 维护原件、来源及页面证据。`workflow.py` 编排导入与提取。`resources.py` 管理在线来源。
- `engine.py` 编排检索与问答。`vector_index.py` 管理向量缓存。`retrieval.py` 和 `mad.py` 实现排序算法与证据核验。`providers.py` 封装模型协议。

React 静态包通过 Qt WebChannel 与 Python 互通，启动不需要 Node 服务。Node 用于构建。原有 Qt 界面可通过 `.venv/bin/python -m marvel_kb.desktop` 启动，供回退和既有交互测试使用。

### 扫描漫画提取

React 书架提供“本地 OCR 当前页”和“批量本地 OCR”。本地 OCR 使用 macOS 的 Apple Vision，需要已安装 Apple 命令行工具（可用 `xcode-select --install` 安装）。识别结果以页为单位保存，可直接用关键词检索并在书架校对。批处理按待提取状态跳过已完成页面。

需要画面描述时，可在配置视觉模型后对待提取页面使用“云端视觉提取”。本地 OCR 只提取文字。

故事对话会检索相关页，结合原页画格与对白，在核验后用连贯段落讲述剧情。启用模型时，所用图片和文字会发送至已配置的模型接口。

## 发布包

包含源码、构建配置和示例。解压后从空白知识库开始，漫画由使用者自行导入。七张横幅使用原创几何图。
